extends SceneTree

## prune_order A/B：删线索尝试顺序 → 窗口命中率（降废品的真指标）
##
## 背景（2026-09-27 实测）：窗口模式的"废品"主因不是生成失败
##（brep_fail/verify_fail/prune_empty/prewon/timeout 全为 0），而是 **peak_miss**
##（难度峰值 max_complexity 没落进请求档）。而峰值由「删完线索后留下的极小集」决定，
## 该集合又由**尝试顺序**决定（删除单调：先删掉越多，后面越容易失败被恢复）。
##
## 本探针只比"哪套顺序让候选更容易落进窗口"，**不动判据**（删除仍要求序贯可解）。
## 判据：in-hard / in-normal 命中率升高且 mean_diff 不降 → 可作为产线默认。
##
## 逐 seed 打印（长跑不被空闲超时打断）；建议后台执行后轮询日志。

const MODS := ["o1_duichuan", "s1_jinxing"]
const SEEDS := 10
const TIMEOUT_MS := 90_000

## [clue, globals, side, mines, 标签]
const CASES := [
	["o1", ["s1"], 7, 20, "s1_o1@7"],
	["o1", ["s1"], 9, 32, "s1_o1@9"],
]

const STRATEGIES := [0, 1, 2, 3]


func _in_window(peak: int, lo: int, hi: int) -> bool:
	return peak >= lo and peak <= hi


func _init() -> void:
	for m in MODS:
		var entry := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(entry):
			var sc: Variant = load(entry)
			if sc != null:
				sc.new().call("on_load")
	print("=== prune_order A/B（%d seed × %d 策略 × %d 用例）===" % [SEEDS, STRATEGIES.size(), CASES.size()])
	for c in CASES:
		var clue: String = c[0]
		var globals: Array = c[1]
		var side: int = c[2]
		var mines: int = c[3]
		var label: String = c[4]
		if not PuzzleGenerator.precheck_rules(clue, globals, Vector2i(side, side), mines)["ok"]:
			print("%s UNSAT（预筛拒绝）" % label)
			continue
		for strat in STRATEGIES:
			var gen := PuzzleGenerator.new()
			gen.prune_order = strat
			var hit := 0
			var in_hard := 0
			var in_normal := 0
			var hist := {}
			var diff_sum := 0.0
			var clue_sum := 0
			var t_sum := 0.0
			for s in range(1, SEEDS + 1):
				var t0 := Time.get_ticks_msec()
				var lv: Dictionary = gen.generate_with_rules(
					clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
				var dt := (Time.get_ticks_msec() - t0) / 1000.0
				t_sum += dt
				if lv.is_empty():
					continue
				hit += 1
				var dp: Dictionary = lv.get("difficulty_profile", {})
				var pk := int(dp.get("max_complexity", -1))
				hist[pk] = int(hist.get(pk, 0)) + 1
				diff_sum += float(dp.get("difficulty", 0.0))
				clue_sum += int(dp.get("clue_count", 0))
				if _in_window(pk, 6, 20):
					in_hard += 1
				if _in_window(pk, 4, 5):
					in_normal += 1
			var ks: Array = hist.keys()
			ks.sort()
			var hs: Array = []
			for k in ks:
				hs.append("%d:%d" % [int(k), int(hist[k])])
			print("%-10s strat=%d  hit=%d/%d  in_hard=%d(%.0f%%)  in_normal=%d(%.0f%%)  mean_diff=%.2f  mean_clue=%.1f  avg=%.1fs  peak={%s}"
				% [label, strat, hit, SEEDS, in_hard, 100.0 * in_hard / maxi(1, hit),
					in_normal, 100.0 * in_normal / maxi(1, hit),
					diff_sum / maxi(1, hit), float(clue_sum) / maxi(1, hit),
					t_sum / SEEDS, ",".join(hs)])
	print("=== A/B 结束 ===")
	quit(0)
