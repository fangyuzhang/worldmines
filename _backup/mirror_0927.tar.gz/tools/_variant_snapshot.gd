extends SceneTree

## 变体基线快照（v2.9.3 变体替换准备）：记录当前规则注册表全量
##（id / kind / describe），供「变体替换」时做新旧对照基线。
const CliShutdown := preload("res://tools/cli_shutdown.gd")


func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var out_path := str(args[0]) if args.size() >= 1 and str(args[0]) != "" else "user://variant_snapshot.json"
	var reg := RuleRegistry.default()
	var rules: Array = []
	for id in reg.all_ids():
		var r: Object = reg.resolve(StringName(id))
		var kind := "?"
		var desc := {}
		if r != null:
			kind = str(r.call("get_kind"))
			var d: Variant = r.call("describe")
			if d is Dictionary:
				desc = d
		rules.append({"id": id, "kind": kind, "describe": desc})
	var doc := {
		"snapshot_at": Time.get_datetime_string_from_system(),
		"clues": [], "globals": [], "all": rules,
	}
	for r in rules:
		if str(r["kind"]) == "clue":
			(doc["clues"] as Array).append(r["id"])
		elif str(r["kind"]) == "global":
			(doc["globals"] as Array).append(r["id"])
	var f := FileAccess.open(out_path, FileAccess.WRITE)
	f.store_string(JSON.stringify(doc, "  "))
	f.close()
	print("变体基线快照: %s（clue %d 个 / global %d 个）" % [out_path, doc["clues"].size(), doc["globals"].size()])
	CliShutdown.request_exit(0)


func _process(_delta: float) -> bool:
	return CliShutdown.poll(self)
