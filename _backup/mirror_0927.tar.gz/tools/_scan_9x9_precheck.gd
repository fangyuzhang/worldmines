extends SceneTree

## 9×9 全组合可行性预检（M5「9×9 扩展层」设计准备，2026-09-16）
## 对内置 92 组合（8 单 C + 7 单 G + 56 G+C + 21 G+G）在 9×9 @32 雷跑 precheck_rules。
## 输出每组合 OK/UNSAT + 汇总不可行清单（M5 验收「9×9 全尺寸预检通过」的硬数据）。
const CliShutdown := preload("res://tools/cli_shutdown.gd")

const CLUES := ["classic", "4n", "clock", "hv", "fr", "loopruns", "distsum", "sc"]
const GLOBALS := ["mx", "rl", "pf", "qd", "dt", "ep", "4c"]


func _initialize() -> void:
	var combos: Array = []
	for c in CLUES:
		combos.append({"id": "c_%s" % c, "clue": c, "globals": []})
	for g in GLOBALS:
		combos.append({"id": "g_%s" % g, "clue": "classic", "globals": [g]})
	for g in GLOBALS:
		for c in CLUES:
			combos.append({"id": "%s_%s" % [g, c], "clue": c, "globals": [g]})
	for i in GLOBALS.size():
		for j in range(i + 1, GLOBALS.size()):
			combos.append({"id": "%s_%s" % [GLOBALS[i], GLOBALS[j]], "clue": "classic", "globals": [GLOBALS[i], GLOBALS[j]]})
	print("=== 9×9 全组合可行性预检（%d 组合 @32 雷）===" % combos.size())
	var bad: Array = []
	var t0 := Time.get_ticks_msec()
	for i in combos.size():
		var cb: Dictionary = combos[i]
		var r: Dictionary = PuzzleGenerator.precheck_rules(StringName(str(cb["clue"])), cb["globals"], Vector2i(9, 9), 32)
		var ok := bool(r.get("ok", false))
		if not ok:
			bad.append(cb["id"])
		print("  [%02d/%02d] %-16s %s%s" % [i + 1, combos.size(), cb["id"],
			"OK" if ok else "UNSAT", "" if ok else "  -- %s" % str(r.get("reason", ""))])
	print("=== 汇总：%d/%d 可行；不可行 %d 项：%s ===" % [
		combos.size() - bad.size(), combos.size(), bad.size(),
		", ".join(bad) if not bad.is_empty() else "（无）"])
	print("耗时 %.1fs" % (float(Time.get_ticks_msec() - t0) / 1000.0))
	CliShutdown.request_exit(0)


func _process(_delta: float) -> bool:
	return CliShutdown.poll(self)
