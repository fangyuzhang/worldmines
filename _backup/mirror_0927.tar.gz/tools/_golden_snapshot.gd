extends SceneTree

## P0 修复前的 **golden 基线快照**（一次性只读探针，不改生产代码）
##
## 目的：把「既有组合」的产物逐字段固化到 tools/_golden_pre_p0.jsonl。
##       P0（给「带隐藏态的线索规则 + 至少一个全局规则」补隐藏态初始化）落地后，
##       用本快照证明既有产物逐字节不变、只新增复合组合。
##
## 固定 seed=1..5、attempts=1（一 seed = 一次尝试，可复现）、timeout_ms=90000。
##
## 用法（项目根，headless，前台同步）：
##   & $GODOT --headless --path . -s res://tools/_golden_snapshot.gd
##
## 【B2 写入守卫（r4 独立核验）】本脚本是**基线生成器**，原先无条件 FileAccess.WRITE
##   覆盖 res://tools/_golden_pre_p0.jsonl —— 一次无意识重跑就销毁「P0 前」证据，
##   事后无法区分「修复有效」与「基线被重写」。故改为：已存在即**拒绝**，
##   除非显式 `--force` 或 `--out=<新路径>`（后者用于 P0 后取新快照做 diff）。
##   用法（注意 Godot 的用户参数需放在 `--` 之后）：
##     & $GODOT --headless --path . -s res://tools/_golden_snapshot.gd -- --out=res://tools/_golden_post_p0.jsonl
##
## 【B3 比对口径】P0 后不得只比 hidden_state 的基数（card）——**同尺寸陈旧态能通过
##   全部基数/坐标在图内断言**（实测污染后 卡数 16→16、与 seed1 同集=true、verify_fail=0）。
##   必须用独立只读 diff 工具对 mines / revealed / hidden_state.*.coords **逐元素**比对。

const MODS := ["o4_bianjing", "o5_xiemai", "s3_wuhuan", "s1_jinxing"]

const SEEDS := 5
const TIMEOUT_MS := 90_000
## 单 seed 超过此值视作异常，跳过该 case 剩余 seed 并留痕（避免长时间静默）。
const MAX_SEED_MS := 180_000

const OUT_PATH := "res://tools/_golden_pre_p0.jsonl"

## [clue, globals, side, mines, 标签]
## 前 7 个 = 既有组合，P0 后**期望逐字节不变**（回归网）。
const CASES := [
	["o4", [], 6, 14, "o4@6"],          # 既有单席位（globals 空）
	["o4", [], 8, 26, "o4@8"],          # 既有单席位
	["o5x", [], 7, 20, "o5x@7"],        # 既有单席位
	["o5x", [], 8, 26, "o5x@8"],        # 既有单席位
	["classic", ["s3"], 7, 20, "classic+s3@7"],   # 既有单全局
	["classic", ["s3"], 8, 26, "classic+s3@8"],   # 既有单全局
	# 【09-27 修正】原第 7 个 case 写作 ["o1", ["s1"], 8, 26, "o1+s1@8"] —— 在本 harness 里是**死 case**：
	# 官方 22 席是「每席一个 mod 目录」（demo/mods/o1_duichuan … z5_dengcha），由
	# ModAPI.bootstrap_bundled_mods() 自举加载；而本脚本只手工加载下面 MODS 里的 4 个
	# （`-s` 型 headless harness 不跑 autoload）⇒ **`o1` 不在本次加载集**，
	# generate_with_rules 在 puzzle_generator.gd:387 直接 return {}
	# ⇒ 5 seed 全部 0.0s 空返回、last_call_stats={}（**空字典 = 「规则不在加载集」的指纹**，
	#   与「生成失败」的 stats 非空可区分）。
	# 改用本加载集内确实存在的 classic+s1（classic 无隐藏态 ⇒ P0 后仍必须逐字节不变）。
	# 注：本 harness 的加载集 ≠ 生产（生产装 22 席）——快照只对「这 4 个 mod」的组合有效。
	["classic", ["s1"], 8, 26, "classic+s1@8"],
	# ---- 后 2 个 = P0 修复域：**隐藏态线索规则 + 全局规则** ----
	# 原脚本只覆盖 globals 为空的隐藏态档（o4/o5x）与无隐藏态的复合档（o1+s1、classic+s3）
	# ⇒ 修复域覆盖 = 0，「逐字节不变」只能证明没改坏旧域（r4 N1/§2）。
	# 这 2 个 case 是**验收锚**：P0 前它们产出的就是「隐藏态未初始化」的坏产物
	#（数字按空状态重算，而所有门禁因单例同源恒等而放行）——故 **P0 后必须变**。
	# 可行性：o4/o5x 属轴 O(OBS)、s1 属轴 S(LOCAL)，compat 走 R1 跨轴正交 = ok，无整除约束。
	["o4", ["s1"], 8, 26, "o4+s1@8"],
	["o5x", ["s1"], 7, 20, "o5x+s1@7"],
]

## P0 后**期望发生变化**的 case（其余 case 期望逐字节不变）——比对工具的判据来源。
const EXPECT_CHANGE := ["o4+s1@8", "o5x+s1@7"]

static func _cli_flag(name: String) -> bool:
	return OS.get_cmdline_user_args().has(name)

## 取 --out=<path>（无则用默认 OUT_PATH）；用户参数须置于 `--` 之后。
static func _cli_out() -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--out=") and a.length() > 6:
			return a.substr(6)
	return OUT_PATH

## [c,r] 字典序：先 c 后 r
static func _pair_less(a: Array, b: Array) -> bool:
	if int(a[0]) != int(b[0]):
		return int(a[0]) < int(b[0])
	return int(a[1]) < int(b[1])

func _init() -> void:
	var t_start := Time.get_ticks_msec()
	for m in MODS:
		var entry := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(entry):
			var sc: Variant = load(entry)
			if sc != null:
				sc.new().call("on_load")
				print("[mods] loaded %s" % m)
		else:
			print("[mods] !! MISSING %s" % entry)
	print("=== golden 快照（%d case × %d seed, attempts=1, timeout=%dms）===" % [CASES.size(), SEEDS, TIMEOUT_MS])

	# B2 写入守卫：基线只能取一次；重跑必须显式 --force，或用 --out= 另存新基线。
	var out_path := _cli_out()
	if FileAccess.file_exists(out_path) and not _cli_flag("--force"):
		print("!! %s 已存在 —— 拒绝覆盖（基线取一次即定；确需重跑请加 --force，或用 -- --out=<新路径> 保留旧基线）" % out_path)
		quit(1)
		return
	var f := FileAccess.open(out_path, FileAccess.WRITE)
	if f == null:
		print("!! 无法写入 %s（err=%d）" % [out_path, FileAccess.get_open_error()])
		quit(1)
		return
	print("写入 %s（%s）" % [out_path, "覆盖(--force)" if FileAccess.file_exists(out_path) else "新建"])

	var meta := {
		"t": "golden_meta",
		"engine": str(Engine.get_version_info().get("string", "")),
		"gen_rev": PuzzleGenerator.GEN_REV,
		"seeds": SEEDS,
		"attempts": 1,
		"timeout_ms": TIMEOUT_MS,
		"mods": MODS,
		"cases": CASES.map(func(c): return c[4]),
		"expect_change": EXPECT_CHANGE,
		"generated_at": Time.get_datetime_string_from_system(),
		"notes": "revealed 无 value 字段（仅 c/r，遮蔽格另含 interval）——第三元素以 \"\" 记 value 缺失、以 \"lo-hi\" 记遮蔽区间。mines/revealed 均按 [c,r] 字典序排序。hidden_state 记录每个规则状态的基数(card)与坐标。",
	}
	f.store_line(JSON.stringify(meta))
	f.flush()

	var summary := {}
	var anomalies: Array = []
	var total_lines := 0

	for c in CASES:
		var clue: String = c[0]
		var globals: Array = c[1]
		var side: int = c[2]
		var mines: int = c[3]
		var label: String = c[4]
		var t_case := Time.get_ticks_msec()
		var hit := 0
		var agg_prune_ms := 0
		var agg_tries := 0
		var agg_ok := 0
		var cards: Array = []
		var skipped := false

		print("--- case %s 开始 ---" % label)
		for s in range(1, SEEDS + 1):
			print("[%s] seed %d 开始..." % [label, s])
			var gen := PuzzleGenerator.new()
			var t_seed := Time.get_ticks_msec()
			var lv: Dictionary = gen.generate_with_rules(
				clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
			var dt_seed := Time.get_ticks_msec() - t_seed
			var st: Dictionary = gen.last_call_stats
			agg_prune_ms += int(st.get("t_prune_ms", 0))
			agg_tries += int(st.get("prune_tries", 0))
			agg_ok += int(st.get("prune_ok", 0))
			if lv.is_empty():
				print("[%s] seed %d 空返回（%.1fs）stats=%s" % [label, s, dt_seed / 1000.0, JSON.stringify(st)])
				continue
			hit += 1

			# mines
			var mines_out: Array = []
			for m in lv.get("mines", []):
				mines_out.append([int(m["c"]), int(m["r"])])
			mines_out.sort_custom(_pair_less)

			# revealed
			var rev_out: Array = []
			var has_interval := false
			for r in lv.get("revealed", []):
				var val := ""
				if r.has("interval"):
					val = "%d-%d" % [int(r["interval"][0]), int(r["interval"][1])]
					has_interval = true
				rev_out.append([int(r["c"]), int(r["r"]), val])
			rev_out.sort_custom(func(a, b): return _pair_less(a, b))

			# difficulty_profile
			var prof: Dictionary = lv.get("difficulty_profile", {})

			# hidden_state
			var hs_out := {}
			var card_total := 0
			var hs: Dictionary = lv.get("hidden_state", {})
			for rid in hs:
				var sstate: Dictionary = hs[rid]
				var coords: Array = []
				var card := 0
				for k in sstate:
					var v: Variant = sstate[k]
					if v is Array:
						for it in v:
							if it is Dictionary and it.has("c") and it.has("r"):
								coords.append([int(it["c"]), int(it["r"])])
							else:
								coords.append([str(it), ""])
					elif v is Dictionary:
						for kk in v:
							coords.append([str(kk), ""])
					else:
						coords.append([str(k), ""])
				card = coords.size()
				coords.sort_custom(func(a, b): return _pair_less(a, b))
				hs_out[str(rid)] = {"card": card, "coords": coords}
				card_total += card
			cards.append(card_total)

			var line := {
				"combo": label,
				"seed": s,
				"size": side,
				"clue_rule": str(lv.get("clue_rule", "")),
				"global_rules": lv.get("global_rules", []),
				"mines": mines_out,
				"revealed": rev_out,
				"has_interval": has_interval,
				"clue_count": int(prof.get("clue_count", -1)),
				"max_complexity": int(prof.get("max_complexity", -1)),
				"difficulty": float(prof.get("difficulty", -1.0)),
				"rounds": int(prof.get("rounds", -1)),
				"profile": str(prof.get("profile", "")),
				"total_mines": int(lv.get("total_mines", -1)),
				"gen_rev": lv.get("gen_rev", null),
				"hidden_state": hs_out,
				"last_call_stats": {
					"t_prune_ms": int(st.get("t_prune_ms", 0)),
					"prune_tries": int(st.get("prune_tries", 0)),
					"prune_ok": int(st.get("prune_ok", 0)),
				},
				"seed_ms": dt_seed,
			}
			f.store_line(JSON.stringify(line))
			f.flush()
			total_lines += 1
			print("[%s] seed %d OK（%.1fs）mines=%d clue=%d maxcplx=%d diff=%.2f hs_card=%d t_prune=%dms trie=%d ok=%d%s"
				% [label, s, dt_seed / 1000.0, mines_out.size(), int(prof.get("clue_count", -1)),
					int(prof.get("max_complexity", -1)), float(prof.get("difficulty", -1.0)),
					card_total, int(st.get("t_prune_ms", 0)), int(st.get("prune_tries", 0)),
					int(st.get("prune_ok", 0)), " [含 interval 遮蔽格]" if has_interval else ""])
			if dt_seed > MAX_SEED_MS:
				print("[%s] !! seed %d 耗时 %.1fs 超阈值 %.0fs，跳过本 case 剩余 seed" % [label, s, dt_seed / 1000.0, MAX_SEED_MS / 1000.0])
				anomalies.append("%s: seed %d 超时跳过(%.1fs)" % [label, s, dt_seed / 1000.0])
				skipped = true
				break

		var dt_case := (Time.get_ticks_msec() - t_case) / 1000.0
		summary[label] = {
			"hit": hit, "attempts": SEEDS if not skipped else hit + 1,
			"avg_s": dt_case / float(SEEDS),
			"t_prune_ms": agg_prune_ms, "prune_tries": agg_tries, "prune_ok": agg_ok,
			"hs_cards": cards,
		}
		print("--- case %s 结束：hit %d/%d, avg %.2fs, hs_cards=%s ---" % [label, hit, SEEDS, dt_case / float(SEEDS), str(cards)])

	f.close()
	print("=== 快照结束：关卡行 %d，总耗时 %.1fs ===" % [total_lines, (Time.get_ticks_msec() - t_start) / 1000.0])
	print("__SUMMARY__ %s" % JSON.stringify(summary))
	print("__EXPECT_CHANGE__ %s（P0 后必须变；其余 case 必须逐字节不变）" % str(EXPECT_CHANGE))
	# 修复域 case 零产出要显式喊出来：P0 前它可能是真实现象（隐藏态未初始化 ⇒ 生成失败/被拒），
	# 也可能是尺寸-雷数不可行 —— 无论哪种都不能以「沉默的空 case」形态混进基线。
	var fix_missed: Array = []
	for lbl in EXPECT_CHANGE:
		if int((summary.get(lbl, {}) as Dictionary).get("hit", 0)) == 0:
			fix_missed.append(lbl)
	if not fix_missed.is_empty():
		print("!! 修复域 case 零产出：%s —— 需人工判读（修复前真实现象 vs 尺寸-雷数不可行）" % str(fix_missed))
	if not anomalies.is_empty():
		print("__ANOMALIES__ %s" % JSON.stringify(anomalies))
	quit(0)
