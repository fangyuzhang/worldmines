$g = 'D:\Godot.NET\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64_console.exe'
$root = 'C:\Users\zjh30\CodeBuddy\20260906184916'
$p = Start-Process -FilePath $g -ArgumentList '--headless','--path','.','-s','res://tools/_hidden_state_audit.gd' -WorkingDirectory $root -RedirectStandardOutput "$root\tools\_audit.log" -RedirectStandardError "$root\tools\_audit.err" -NoNewWindow -PassThru
"AUDIT_PID=$($p.Id)"
