# 批量重放验证：隐藏态规则（o4/o5x）盘——「载盘推理」vs「同 seed 重放恢复隐藏态后推理」。
# 用途：① 定量证明「载盘隐藏态丢失 → 推理踩雷」；② 验证「seed 重放」作为存量抢救方案。
# 用法：godot --headless --path . -s res://tools/_replay_verify.gd -- <dir>
extends SceneTree

const CliShutdown := preload("res://tools/cli_shutdown.gd")


func _initialize() -> void:
	var mods_dir := DirAccess.open("res://demo/mods")
	if mods_dir != null:
		for sub in mods_dir.get_directories():
			var entry := "res://demo/mods/%s/entry.gd" % sub
			if ResourceLoader.exists(entry):
				var sc: Variant = load(entry)
				if sc != null:
					sc.new().call("on_load")
	var args := OS.get_cmdline_user_args()
	var dir_path := str(args[0]) if args.size() > 0 else "res://_staged_levels/harvest_0915b/batch_o5x"
	var files := _list_json(dir_path)
	print("目录 %s 共 %d 盘" % [dir_path, files.size()])
	var before_ok := 0
	var after_ok := 0
	var replay_fail := 0
	var after_fail := 0
	var t0 := Time.get_ticks_msec()
	for i in files.size():
		var path := files[i]
		var f := FileAccess.open(path, FileAccess.READ)
		if f == null:
			continue
		var level: Dictionary = JSON.parse_string(f.get_as_text())
		f.close()
		if bool(ProofLog.build(level).get("solved", false)):
			before_ok += 1
		# 同 seed 重放 place_mines（恢复隐藏态）
		var size: Dictionary = level.get("size", {})
		var rows := int(size.get("rows", 0))
		var cols := int(size.get("cols", 0))
		var seed_v := int(level.get("seed", 0))
		var mc := int(level.get("total_mines", 0))
		var clue_id := str(level.get("clue_rule", ""))
		var rule: Object = RuleRegistry.default().resolve(StringName(clue_id))
		var matched := false
		if rule != null and rule.has_method("place_mines"):
			var mine_set := {}
			for m in level.get("mines", []):
				mine_set[Vector2i(int(m["c"]), int(m["r"]))] = true
			for attempt in 40:
				var rng := RandomNumberGenerator.new()
				rng.seed = seed_v * 1000003 + attempt
				var mines: Array = rule.call("place_mines", rng, cols, rows, mc)
				var s := {}
				for m in mines:
					s[m] = true
				var same := s.size() == mine_set.size()
				if same:
					for k in s:
						if not mine_set.has(k):
							same = false
							break
				if same:
					matched = true
					break
		if not matched:
			replay_fail += 1
			continue
		if bool(ProofLog.build(level).get("solved", false)):
			after_ok += 1
		else:
			after_fail += 1
		if (i + 1) % 50 == 0:
			print("  进度 %d/%d elapsed=%ds" % [i + 1, files.size(), (Time.get_ticks_msec() - t0) / 1000])
	print("=== 汇总 ===")
	print("盘数=%d 重放失败=%d" % [files.size(), replay_fail])
	print("重放前可解=%d / 重放后可解=%d / 重放后仍失败=%d" % [before_ok, after_ok, after_fail])
	CliShutdown.request_exit(0)


func _process(_delta: float) -> bool:
	return CliShutdown.poll(self)


func _list_json(dir_path: String) -> Array[String]:
	var out: Array[String] = []
	var dir := DirAccess.open(dir_path)
	if dir == null:
		return out
	dir.list_dir_begin()
	var n := dir.get_next()
	while n != "":
		if dir.current_is_dir():
			out.append_array(_list_json(dir_path.path_join(n)))
		elif n.ends_with(".json") and not n.begins_with("all_report"):
			out.append(dir_path.path_join(n))
		n = dir.get_next()
	dir.list_dir_end()
	out.sort()
	return out
