extends SceneTree

## Stage-0 测量探针（一次性诊断工具，**只读，不改生产代码**）
##
## M1：build_spec 组装耗时占比
##   A 组复合：o1 + s1 @ 8x8 / 26 雷
##   B 组单席位：classic + s3 @ 7x7 / 20 雷
##   ① 先产一关 → 用线索规则正向求值重建 active（level["revealed"] 不落 value）
##   ② oracle.build_spec(active, [], {}) × 200 次，报平均 μs
##   ③ 同规格 3 seed 生成，报平均总耗时 / t_prune_ms / prune_tries
##   ④ 粗估：build_spec_us × prune_tries × 10 / 1e6 = 组装秒数 → 占 prune 秒数百分比（粗估）
##
## M2：雷数 → 窗口命中率映射（o1 + s1，size ∈ {7,9}）
##   对 CANDIDATES[size] 每个 mines：先 CP-SAT 可行性；再 8 seed 生成，
##   记录每关 difficulty_profile.max_complexity（peak），按档统计命中。
##
## 用法（项目根，headless）：
##   & $GODOT --headless --path . -s res://tools/_stage0_probe.gd            # M1+M2
##   & $GODOT --headless --path . -s res://tools/_stage0_probe.gd -- m1      # 只 M1
##   & $GODOT --headless --path . -s res://tools/_stage0_probe.gd -- m2      # 只 M2

const MODS := ["o1_duichuan", "s1_jinxing", "s3_wuhuan"]
const TIMEOUT_MS := 90_000
const BUILD_SPEC_ITERS := 200
const M2_SEEDS := 8
const SEED_SLOW_S := 180.0        # 单 seed 墙钟 > 3min → 跳过该 case 剩余 seed
const LOG_PATH := "res://tools/_stage0_out.txt"

var _log_file: FileAccess = null


func _log(s: String) -> void:
	print(s)
	if _log_file != null:
		_log_file.store_line(s)
		_log_file.flush()


func _load_mods() -> void:
	for m in MODS:
		var entry := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(entry):
			var sc: Variant = load(entry)
			if sc != null:
				sc.new().call("on_load")


func _resolve_globals(ids: Array) -> Array:
	var reg := RuleRegistry.default()
	var out: Array = []
	for gid in ids:
		var g: Object = reg.resolve(StringName(str(gid)))
		if g != null:
			out.append(g)
	return out


func _init() -> void:
	_log_file = FileAccess.open(LOG_PATH, FileAccess.WRITE)
	_load_mods()
	var args := OS.get_cmdline_user_args()
	var mode := "all"
	if args.size() > 0:
		mode = str(args[0]).to_lower()
	_log("=== Stage-0 测量探针 mode=%s ===" % mode)
	_log("godot=%s  cpsat_available=%s" % [
		str(Engine.get_version_info().get("string", "?")), str(RuleCpSat.available())])
	if mode == "all" or mode == "m1":
		_m1()
	if mode == "all" or mode == "m2":
		_m2()
	_log("=== 探针结束 ===")
	if _log_file != null:
		_log_file.close()
	quit(0)


# ==================== M1 ====================

func _level_mine_set(level: Dictionary) -> Dictionary:
	var ms := {}
	for m in level.get("mines", []):
		ms[Vector2i(int(m["c"]), int(m["r"]))] = true
	return ms


## 从产物重建 active。level["revealed"] 只落 {r,c}（不落 value），
## 故用线索规则的 compute_clue 正向求值（与生成器内部同函数、同口径）。
func _active_from_level(level: Dictionary, clue_id: String, side: int) -> Dictionary:
	var reg := RuleRegistry.default()
	var rule: Object = reg.resolve(StringName(clue_id))
	var ms := _level_mine_set(level)
	var gs := Vector2i(side, side)
	var active := {}
	for rv in level.get("revealed", []):
		if rv.has("interval"):
			continue  # 遮蔽格（本测量 mask_count=0，正常不出现）
		var pos := Vector2i(int(rv["c"]), int(rv["r"]))
		var v: Variant = rule.compute_clue(ms, pos, gs)
		if v is int and int(v) >= 0:
			active[pos] = int(v)
	return active


## 退化路径：生成失败时自建确定性随机雷盘（不满足全局规则），用线索规则正向求值。
func _degraded_active(clue_id: String, side: int, mines: int, seed: int) -> Dictionary:
	var reg := RuleRegistry.default()
	var rule: Object = reg.resolve(StringName(clue_id))
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var cells: Array[Vector2i] = []
	for r in side:
		for c in side:
			cells.append(Vector2i(c, r))
	var ms := {}
	for i in mines:
		if cells.is_empty():
			break
		var j := rng.randi_range(0, cells.size() - 1)
		ms[cells[j]] = true
		cells.remove_at(j)
	var gs := Vector2i(side, side)
	var active := {}
	for r in side:
		for c in side:
			var pos := Vector2i(c, r)
			if ms.has(pos):
				continue
			var v: Variant = rule.compute_clue(ms, pos, gs)
			if v is int and int(v) >= 0:
				active[pos] = int(v)
	return active


func _m1_case(label: String, clue: String, globals: Array, side: int, mines: int) -> void:
	var t_case0 := Time.get_ticks_msec()
	_log("--- M1 %s: clue=%s globals=%s %dx%d mines=%d ---" % [label, clue, str(globals), side, side, mines])
	_log("  RuleFeasibility.query=%s" % str(RuleFeasibility.query(clue, globals, side, mines)))

	# ① 产一关 → 重建 active
	var gen0 := PuzzleGenerator.new()
	var t0 := Time.get_ticks_msec()
	var lv: Dictionary = gen0.generate_with_rules(
		clue, globals, Vector2i(side, side), mines, 1, 0, 1, null, TIMEOUT_MS)
	var dt0 := (Time.get_ticks_msec() - t0) / 1000.0
	var active := {}
	var actual_mines := mines
	var note := ""
	if lv.is_empty():
		active = _degraded_active(clue, side, mines, 1)
		note = "【退化】生成失败(%.1fs)→自建随机雷盘求值" % dt0
	else:
		active = _active_from_level(lv, clue, side)
		actual_mines = int(lv.get("total_mines", mines))
		note = "实测关: revealed=%d active=%d peak=%d" % [
			(lv.get("revealed", []) as Array).size(), active.size(),
			int(lv.get("difficulty_profile", {}).get("max_complexity", 0))]
	_log("  ① 生成 %.2fs  %s" % [dt0, note])
	if active.is_empty():
		_log("  !! active 为空，跳过本 case")
		return

	# ② build_spec × 200
	var oracle := RuleOracle.new(
		RuleRegistry.default().resolve(StringName(clue)), _resolve_globals(globals),
		Vector2i(side, side), actual_mines, null)
	oracle.build_spec(active, [], {})  # 预热
	var t_us0 := Time.get_ticks_usec()
	for _i in BUILD_SPEC_ITERS:
		oracle.build_spec(active, [], {})
	var total_us := Time.get_ticks_usec() - t_us0
	var avg_us := float(total_us) / float(BUILD_SPEC_ITERS)
	_log("  ② build_spec ×%d: total=%.1fms  avg=%.1f us/次" % [BUILD_SPEC_ITERS, total_us / 1000.0, avg_us])

	# ③ 3 seed 生成
	var hit := 0
	var sum_s := 0.0
	var sum_prune := 0.0
	var sum_tries := 0
	for s in [1, 2, 3]:
		var gen := PuzzleGenerator.new()
		var st := Time.get_ticks_msec()
		var lv2: Dictionary = gen.generate_with_rules(
			clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
		var dt := (Time.get_ticks_msec() - st) / 1000.0
		if not lv2.is_empty():
			hit += 1
		var prune_s := float(gen.last_call_stats.get("t_prune_ms", 0)) / 1000.0
		var tries := int(gen.last_call_stats.get("prune_tries", 0))
		sum_s += dt
		sum_prune += prune_s
		sum_tries += tries
		_log("  ③ seed=%d %s t=%.2fs t_prune=%.2fs tries=%d peak=%d" % [
			s, "OK" if not lv2.is_empty() else "MISS", dt, prune_s, tries,
			int(lv2.get("difficulty_profile", {}).get("max_complexity", -1))])
	var n := 3.0
	var gen_avg := sum_s / n
	var prune_avg := sum_prune / n
	var tries_avg := float(sum_tries) / n

	# ④ 粗估
	var est_s := avg_us * tries_avg * 10.0 / 1_000_000.0
	var est_pct := 100.0 * est_s / maxf(0.001, prune_avg)
	_log("  ④ build_spec_us=%.1f  gen_avg_s=%.3f  t_prune_avg_s=%.3f  prune_tries_avg=%.1f  hit=%d/3" % [
		avg_us, gen_avg, prune_avg, tries_avg, hit])
	_log("     粗估(每次 prune try ≈10 次 build_spec): 组装 %.3fs / prune %.3fs = %.2f%%  [粗估，非实测]" % [
		est_s, prune_avg, est_pct])
	_log("  墙钟 %.1fs" % [(Time.get_ticks_msec() - t_case0) / 1000.0])


func _m1() -> void:
	_log("")
	_log("=== M1: build_spec 组装耗时占比 ===")
	_m1_case("A-复合", "o1", ["s1"], 8, 26)
	_m1_case("B-单席位", "classic", ["s3"], 7, 20)


# ==================== M2 ====================

func _m2_case(side: int, mines: int) -> void:
	var tag := "[%dx%d m=%d]" % [side, side, mines]
	var t_case0 := Time.get_ticks_msec()
	if not RuleFeasibility.query("o1", ["s1"], side, mines):
		_log("  %s UNSAT（跳过）" % tag)
		return
	var hist := {}
	var hits := 0
	var sum_s := 0.0
	var seeds_run := 0
	var skipped := 0
	for s in range(1, M2_SEEDS + 1):
		var gen := PuzzleGenerator.new()
		var st := Time.get_ticks_msec()
		var lv: Dictionary = gen.generate_with_rules(
			"o1", ["s1"], Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
		var dt := (Time.get_ticks_msec() - st) / 1000.0
		sum_s += dt
		seeds_run += 1
		if lv.is_empty():
			_log("  %s seed=%d MISS %.1fs  stats=%s" % [
				tag, s, dt, str(gen.last_call_stats)])
		else:
			hits += 1
			var peak := int(lv.get("difficulty_profile", {}).get("max_complexity", 0))
			hist[peak] = int(hist.get(peak, 0)) + 1
			_log("  %s seed=%d peak=%d %.1fs  clue=%d" % [
				tag, s, peak, dt, int(lv.get("difficulty_profile", {}).get("clue_count", 0))])
		if dt > SEED_SLOW_S:
			skipped = M2_SEEDS - s
			_log("  %s !!! 单 seed %.1fs > %.0fs，跳过剩余 %d seed" % [tag, dt, SEED_SLOW_S, skipped])
			break
	var easy := 0
	var normal := 0
	var hard := 0
	var low := 0
	var other := 0
	for k in hist:
		var kk := int(k)
		if kk >= 2 and kk <= 3:
			easy += int(hist[k])
		elif kk >= 4 and kk <= 5:
			normal += int(hist[k])
		elif kk >= 6 and kk <= 20:
			hard += int(hist[k])
		elif kk <= 1:
			low += int(hist[k])
		else:
			other += int(hist[k])
	var h := maxi(1, hits)
	var hpct := func(x: int) -> float: return 100.0 * float(x) / float(h)
	_log("  ROW %s hit=%d/%d%s avg_s=%.2f hist=%s" % [
		tag, hits, seeds_run, (" 跳过%d" % skipped) if skipped > 0 else "",
		sum_s / maxf(1.0, float(seeds_run)), _hist_str(hist)])
	_log("      easy(peak2-3)=%d(%.1f%%) normal(4-5)=%d(%.1f%%) hard(6-20)=%d(%.1f%%) low(0-1)=%d other=%d  [分母=成功关数 %d]" % [
		easy, hpct.call(easy), normal, hpct.call(normal), hard, hpct.call(hard), low, other, hits])
	_log("      墙钟 %.1fs" % [(Time.get_ticks_msec() - t_case0) / 1000.0])


func _hist_str(hist: Dictionary) -> String:
	var keys: Array = hist.keys()
	keys.sort()
	var parts: Array = []
	for k in keys:
		parts.append("%d×%d" % [int(k), int(hist[k])])
	return "{" + ",".join(parts) + "}"


func _m2() -> void:
	_log("")
	_log("=== M2: o1+s1 雷数 → 难度窗口命中率 ===")
	for side in [7, 9]:
		var cands: Array = RuleFeasibility.CANDIDATES.get(side, [])
		_log("--- size=%dx%d  候选雷数=%s ---" % [side, side, str(cands)])
		for mines in cands:
			_m2_case(side, int(mines))
