extends Node

## 临时观感验收工具（tools/_*.gd 已 gitignore，不入库）：
## 用**真实渲染路径**（GameSession.start_level + BoardView）截一张等轴菱面盘，
## 验证「看起来像立方体阵列」这件事本身，而不是只看数据。
##   godot --path . res://tools/_shot_iso.tscn -- iso_02.json

const OUT := "res://demo/web"

func _ready() -> void:
	get_window().size = Vector2i(1280, 720)
	for i in 5:
		await get_tree().process_frame

	var level_name := "iso_02.json"
	for a in OS.get_cmdline_user_args():
		var s := str(a).strip_edges()
		if s.ends_with(".json"):
			level_name = s
	var path := "res://levels/" + level_name
	if not GameSession.start_level(path):
		push_error("start_level 失败：%s" % path)
		get_tree().quit(1)
		return
	for i in 5:
		await get_tree().process_frame

	var bv: Control = load("res://ui/board_view.tscn").instantiate()
	add_child(bv)
	bv.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for i in 10:
		await get_tree().process_frame

	var img := get_viewport().get_texture().get_image()
	var out := "%s/iso_%s.png" % [OUT, level_name.get_basename()]
	var err: int = img.save_png(out)
	print("[shot] %s → %s" % [out, "OK" if err == OK else "ERR %d" % err])
	get_tree().quit(0 if err == OK else 1)
