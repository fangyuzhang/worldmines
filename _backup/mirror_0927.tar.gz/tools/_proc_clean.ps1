# 只终止命令行里出现以下探针脚本的 Godot 进程——绝不按进程名一律杀（避免误杀编辑器/游戏）
$targets = @('_p0_verify.gd', '_golden_snapshot.gd')
Get-WmiObject Win32_Process -Filter "Name like '%Godot%'" | ForEach-Object {
    $cl = $_.CommandLine
    $procId = $_.ProcessId
    $hit = $false
    foreach ($t in $targets) { if ($cl -and $cl.Contains($t)) { $hit = $true } }
    $short = if ($cl) { $cl.Substring(0, [Math]::Min(110, $cl.Length)) } else { '(no cmdline)' }
    if ($hit) {
        "KILL $procId  $short"
        Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
    } else {
        "KEEP $procId  $short"
    }
}
Start-Sleep -Seconds 2
'--- remaining ---'
Get-Process | Where-Object { $_.ProcessName -like '*Godot*' } | Select-Object -ExpandProperty Id
