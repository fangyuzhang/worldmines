#!/bin/bash
# 部署前状态核对：量产是否在跑、交接守护是否已就位/已触发、服务器文件现状
echo "=== 1. 量产进程 ==="
ps -eo pid,etime,pcpu,pmem,args --sort=-pcpu | grep -E "thin_fill_plan|run_window_production|godot" | grep -v grep || echo "(无量产进程)"
echo
echo "=== 2. 计划/守护脚本 ==="
ls -la /root/thin_fill_plan*.sh /root/handoff*.sh /root/upgrade_code.sh 2>/dev/null || true
echo "--- 计划日志尾部（判断跑到哪一轮）---"
for f in /root/gen_window_*.log; do [ -f "$f" ] && echo "--- $f ($(stat -c%s "$f")B, mtime $(stat -c%y "$f")) ---" && tail -3 "$f"; done
echo
echo "=== 3. 交接守护状态 ==="
ps -eo pid,etime,args | grep -E "handoff|wait.*plan" | grep -v grep || echo "(无交接守护进程)"
echo
echo "=== 4. 服务器关键文件 vs 期望 ==="
for f in core/puzzle_generator.gd core/rule_plugin.gd core/rule_oracle.gd solver/RuleSolver.cs tools/thin_cells.py demo/mods/o4_bianjing/entry.gd demo/mods/o5_xiemai/entry.gd demo/mods/o5b_duijiao/entry.gd; do
  p="/root/minesweeper/$f"
  if [ -f "$p" ]; then
    echo "  $f  $(stat -c%s "$p")B  md5=$(md5sum "$p" | cut -c1-8)  mtime=$(stat -c%y "$p" | cut -c1-19)"
  else
    echo "  $f  ** 缺失 **"
  fi
done
echo
echo "=== 5. dll 与磁盘 ==="
stat -c 'wm_server.dll %sB %y' /root/minesweeper/.godot/mono/temp/bin/Debug/wm_server.dll 2>/dev/null || echo "dll 缺失"
df -h /root | tail -1
free -m | head -2
