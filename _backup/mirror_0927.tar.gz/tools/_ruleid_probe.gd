extends SceneTree

## 一次性探针：在**指定加载集**下，哪些规则 id 真正可解析。
##
## 【为何要有这个探针】官方 22 席是「每席一个 mod 目录」（res://demo/mods/o1_duichuan … z5_dengcha），
## 由 `ModAPI.bootstrap_bundled_mods()` 自举加载；而 `-s script.gd` 这类 headless harness
## **不会跑 autoload**，必须自己 load + on_load。于是「规则是否可用」**完全取决于加载集**：
##   实测（只装 4 个 mod 的 golden harness）`o1` 解析为 null → `generate_with_rules` 在
##   puzzle_generator.gd:387 / :405 直接 return {}，返回的 `last_call_stats` 是**空字典**。
##   ⇒ 空字典就是「规则不在本次加载集」的指纹，与「生成失败」（stats 非空）可区分。
##
## 用法：& $GODOT --headless --path . -s res://tools/_ruleid_probe.gd -- --all
##   --all = 镜像生产自举（demo/mods 下除 BUNDLED_SKIP 外全加载）
##   缺省  = 只加载 golden harness 的 4 个 mod（用于复现 golden 的死 case）
##
## 注意 BUNDLED_SKIP（core/mod_api.gd:42）：o5_sanjiao / o5b_duijiao / custom_rule_mod /
## hpair_rule_mod / legacy_rules —— 生产默认**不**加载，但 `--mods` 批产路径按目录名直载会绕过。

const SKIP := ["o5_sanjiao", "o5b_duijiao", "custom_rule_mod", "hpair_rule_mod", "legacy_rules"]
const GOLDEN4 := ["o4_bianjing", "o5_xiemai", "s3_wuhuan", "s1_jinxing"]

const IDS := ["o1", "o2", "o3", "o4", "o5x", "o6", "o7", "o8", "o9", "o10",
	"s1", "s2", "s3", "s4", "s5", "s6", "s7",
	"z1", "z2", "z3", "z4", "z5", "classic", "pf", "mx", "ep", "rl", "qd", "dt"]


func _init() -> void:
	var use_all := OS.get_cmdline_user_args().has("--all")
	var dirs: Array = []
	if use_all:
		var d := DirAccess.open("res://demo/mods")
		if d != null:
			for name in d.get_directories():
				if not SKIP.has(name):
					dirs.append(name)
	else:
		dirs = GOLDEN4.duplicate()
	var loaded: Array = []
	var failed: Array = []
	for m in dirs:
		var p := "res://demo/mods/%s/entry.gd" % m
		if not ResourceLoader.exists(p):
			failed.append("%s(no entry)" % m)
			continue
		var sc: Variant = load(p)
		if sc == null:
			failed.append("%s(load null)" % m)
			continue
		sc.new().call("on_load")
		loaded.append(m)
	print("__LOADSET__ %s（dirs=%d loaded=%d）" % ["ALL" if use_all else "GOLDEN4", dirs.size(), loaded.size()])
	if not failed.is_empty():
		print("__LOADFAIL__ %s" % str(failed))

	var reg := RuleRegistry.default()
	var missing: Array = []
	var clue: Array = []
	var glb: Array = []
	for id in IDS:
		var r: Object = reg.resolve(StringName(str(id)))
		if r == null:
			missing.append(id)
		elif r.get_kind() == RulePlugin.KIND_CLUE:
			clue.append(id)
		else:
			glb.append(id)
	print("__MISSING__ %s" % str(missing))
	print("__CLUE__ %s" % str(clue))
	print("__GLOBAL__ %s" % str(glb))
	quit(0)
