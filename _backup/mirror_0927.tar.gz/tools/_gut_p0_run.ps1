$g = 'D:\Godot.NET\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64_console.exe'
Set-Location 'C:\Users\zjh30\CodeBuddy\20260906184916'
& $g --headless --path . -s addons/gut/gut_cmdln.gd -gdir=res://test/unit -gexit *> tools\_gut_p0.log
'--- tail ---'
Get-Content tools\_gut_p0.log -Tail 6
'--- summary ---'
Get-Content tools\_gut_p0.log | Select-String -Pattern 'Scripts|Tests|Passing|Failing|Risky|Asserts|All tests passed|failing|Pending' | Select-Object -Last 14
