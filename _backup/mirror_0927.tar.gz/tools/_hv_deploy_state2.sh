#!/bin/bash
# 部署决策用：守护状态 + 那个来路不明的 cmp 计划 + 磁盘/内存
echo "=== 3. 交接守护/计划父进程 ==="
ps -eo pid,ppid,etime,pcpu,args | grep -E "thin_fill_plan|handoff|wait_plan|nohup" | grep -v grep || echo "(无)"
echo
echo "=== 3b. /root 下今天新增的脚本 ==="
find /root -maxdepth 1 -name "*.sh" -newermt "2026-09-27 00:00" -printf "%TY-%Tm-%Td %TH:%TM  %10s  %p\n" 2>/dev/null | sort
echo
echo "=== 3c. thin_fill_plan_cmp.sh 是什么（头 25 行）==="
head -25 /root/thin_fill_plan_cmp.sh 2>/dev/null || echo "(不存在)"
echo
echo "=== 3d. 两个计划的轮次/单元数对比 ==="
for f in /root/thin_fill_plan.sh /root/thin_fill_plan_v2.sh /root/thin_fill_plan_cmp.sh; do
  [ -f "$f" ] || continue
  echo "--- $f ---"
  echo "  行数=$(wc -l < "$f")  run_round 调用=$(grep -c 'run_round ' "$f")  窗口数=$(grep -c 'gen_window_' "$f")"
  grep -m3 -n "GEN_WINDOWS\|WINDOWS=\|for w in\|TAGS=" "$f" | head -3
done
echo
echo "=== 4. 服务器关键文件 ==="
for f in core/puzzle_generator.gd core/rule_plugin.gd core/rule_oracle.gd solver/RuleSolver.cs tools/thin_cells.py tools/upgrade_code.sh demo/mods/o4_bianjing/entry.gd demo/mods/o5_xiemai/entry.gd demo/mods/o5b_duijiao/entry.gd; do
  p="/root/minesweeper/$f"
  if [ -f "$p" ]; then
    echo "  $f  $(stat -c%s "$p")B  md5=$(md5sum "$p" | cut -c1-8)  mtime=$(stat -c%y "$p" | cut -c1-19)"
  else
    echo "  $f  ** 缺失 **"
  fi
done
echo
echo "=== 5. dll/磁盘/内存 ==="
stat -c 'wm_server.dll %sB %y' /root/minesweeper/.godot/mono/temp/bin/Debug/wm_server.dll 2>/dev/null || echo "dll 缺失"
df -h /root | tail -1
free -m | head -2
echo
echo "=== 6. 本轮窗口事件（是否仍在产出）==="
tail -5 /root/gen_window_s7_normal.log 2>/dev/null || echo "(无 s7_normal 日志)"
