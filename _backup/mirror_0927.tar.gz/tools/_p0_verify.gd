extends SceneTree

## P0 验收探针（2026-09-27）：验证「隐藏态在复合档被正确初始化」。
##
## 判据（r4 独立核验要求，逐条可观测）：
##   ① 非空：声明 hidden_state 的规则落盘必须带该字段（空态 = 退化成另一条规则）；
##   ② 基数 = 当前盘面的 k（o4/o5x 的 k=floor(格数*k_ratio)，默认 0.25）
##      —— **跨尺寸污染**在此暴露：7×7 期望 12，若继承 8×8 的 16 即 FAIL；
##   ③ per-seed 相异：3 个 seed 的隐藏坐标集必须互不相同
##      —— 「跨 seed 同集」是 place_mines 未被执行的铁证（stage0c S3b 实测指纹）；
##   ④ 顺序无关：先跑别的档、甚至先用 8×8 污染，再跑 7×7 复合档，基数仍须是 12。
##
## 只读：不改任何生产文件，不写产物。用法：
##   & $GODOT --headless --path . -s res://tools/_p0_verify.gd

const MODS := ["o4_bianjing", "o5_xiemai", "s3_wuhuan", "s1_jinxing"]
const SEEDS := 3


func _init() -> void:
	for m in MODS:
		var p := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(p):
			load(p).new().call("on_load")
	var t0 := Time.get_ticks_msec()
	# ④ 顺序无关（全新会话第一盘就是这个复合档；其后紧跟另一档）
	_run("A fresh:o4+s1@8(期望16)", "o4", ["s1"], 8, 26)
	_run("B fresh:o5x+s1@7(期望12)", "o5x", ["s1"], 7, 20)
	# ④ 跨尺寸污染：先造 8×8 的 o5x（k=16），再跑 7×7 复合档
	_run("C pollute:o5x@8", "o5x", [], 8, 26)
	_run("D after-pollute:o5x+s1@7(期望12，不得继承16)", "o5x", ["s1"], 7, 20)
	print("=== P0 探针结束 %.1fs ===" % ((Time.get_ticks_msec() - t0) / 1000.0))
	quit(0)


func _positions(state: Dictionary) -> Array:
	var out: Array = []
	for k in state:
		var v: Variant = state[k]
		if v is Array:
			for it in v:
				if it is Dictionary and it.has("c") and it.has("r"):
					out.append("(%d,%d)" % [int(it["c"]), int(it["r"])])
				else:
					out.append("(%s)" % str(it))
		else:
			out.append("(%s)" % str(k))
	out.sort()
	return out


func _run(tag: String, clue: String, globals: Array, side: int, mines: int) -> void:
	var expect_k := maxi(1, int(floor(float(side * side) * 0.25)))
	var cards: Array = []
	var sigs: Array = []
	var seen := {}
	var uninit := 0
	var empties := 0
	for s in range(1, SEEDS + 1):
		var gen := PuzzleGenerator.new()
		var lv: Dictionary = gen.generate_with_rules(
			clue, globals, Vector2i(side, side), mines, s, 0, 1, null, 90000)
		if lv.is_empty():
			empties += 1
			print("[%s] seed %d 空返回 stats=%s" % [tag, s, JSON.stringify(gen.last_call_stats)])
			continue
		var st: Dictionary = (lv.get("hidden_state", {}) as Dictionary).get(clue, {})
		var pos := _positions(st)
		cards.append(pos.size())
		var sig := ",".join(pos)
		sigs.append(sig)
		if sig != "":
			seen[sig] = true
		if st.is_empty():
			uninit += 1
		var kstat := gen.last_call_stats
		print("[%s] seed %d 盘OK card=%d(期望%d) hs_card_stat=%d hs_uninit=%d verify=%s" % [
			tag, s, pos.size(), expect_k, int(kstat.get("hs_uninit", 0)),
			int(kstat.get("hs_uninit", 0)), JSON.stringify(kstat)])
	var distinct := seen.size()
	var verdict := "PASS"
	if empties > 0 or uninit > 0 or cards.is_empty():
		verdict = "FAIL(空/未初始化)"
	elif cards.any(func(c): return int(c) != expect_k):
		verdict = "FAIL(基数≠k)"
	elif distinct < cards.size():
		verdict = "FAIL(跨seed同集)"
	print("__P0__ %s  cards=%s 期望k=%d distinct_sigs=%d/%d uninit=%d empties=%d  => %s" % [
		tag, str(cards), expect_k, distinct, cards.size(), uninit, empties, verdict])
