extends SceneTree

## 阶段耗时/废品构成探针（一次性诊断工具，不改生产）
##
## 目的：为 ⑤（降废品）/⑥（吃满 2 核）提供**实测定位**，而不是凭感觉改算法。
## 对每个「组合×尺寸」跑 N 个固定 seed（attempts=1：一颗种子 = 一次尝试），
## 汇总 generate_with_rules 自带的 last_call_stats：
##   t_place / t_prune / t_verify  → 时间花在哪个阶段
##   brep_fail / prune_empty / verify_fail / prewon / timeout → 废品出在哪一类
##
## 用法（项目根，headless）：
##   & $GODOT --headless --path . -s res://tools/_phase_probe.gd

const MODS := ["o4_bianjing", "s1_jinxing", "z1_jingxiang", "z3_sixiang", "z5_dengcha",
	"s7_fenliang", "s5_hanglie", "s4_yangcong", "s6_duou", "o5_xiemai",
	"o3_fendang", "o2_linxu", "o10_huanyou", "s2_zhongxin", "s3_wuhuan", "z4_hangliesu"]

const SEEDS := 6
const TIMEOUT_MS := 30_000

## [clue, globals, side, mines, 标签]
const CASES := [
	["o4", [], 6, 14, "o4@6"],
	["classic", ["s1"], 6, 14, "s1@6"],
	["classic", ["z1"], 6, 14, "z1@6"],
	["classic", ["s3"], 6, 14, "s3@6"],
	["classic", ["z3"], 6, 14, "z3@6"],
	["classic", ["s5"], 6, 14, "s5@6"],
	["classic", ["mx"], 6, 14, "mx@6"],
	["classic", ["qd"], 7, 20, "qd@7"],
]

func _init() -> void:
	for m in MODS:
		var entry := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(entry):
			var sc: Variant = load(entry)
			if sc != null:
				sc.new().call("on_load")
	print("=== 阶段探针（每格 %d seed × attempts=1, timeout=%dms）===" % [SEEDS, TIMEOUT_MS])
	print("case      hit  t_place_s t_prune_s t_verify_s  brep prune_empty verify prewon timeout  avg_s")
	for c in CASES:
		var clue: String = c[0]
		var globals: Array = c[1]
		var side: int = c[2]
		var mines: int = c[3]
		var label: String = c[4]
		# 先做数学可行性预筛（与批产工具同入口）：UNSAT 组合直接标出，不浪费 seed
		if not PuzzleGenerator.precheck_rules(clue, globals, Vector2i(side, side), mines)["ok"]:
			print("%-9s UNSAT（预筛拒绝，不该进产线）" % label)
			continue
		var gen := PuzzleGenerator.new()
		var hit := 0
		var t0 := Time.get_ticks_msec()
		var agg := {"t_place_ms": 0, "t_prune_ms": 0, "t_verify_ms": 0,
			"brep_fail": 0, "prune_empty": 0, "verify_fail": 0, "prewon": 0, "timeout": 0,
			"attempts": 0, "prune_timeout": 0}
		for s in range(1, SEEDS + 1):
			var lv: Dictionary = gen.generate_with_rules(
				clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
			if not lv.is_empty():
				hit += 1
			for k in agg:
				agg[k] = int(agg[k]) + int(gen.last_call_stats.get(k, 0))
		var dt := (Time.get_ticks_msec() - t0) / 1000.0
		print("%-9s %d/%d  %7.2f %9.2f %10.2f  %5d %10d %6d %6d %7d  %5.2f%s" % [
			label, hit, SEEDS,
			float(agg["t_place_ms"]) / 1000.0, float(agg["t_prune_ms"]) / 1000.0,
			float(agg["t_verify_ms"]) / 1000.0,
			int(agg["brep_fail"]), int(agg["prune_empty"]), int(agg["verify_fail"]),
			int(agg["prewon"]), int(agg["timeout"]), dt / float(SEEDS),
			("  ⚠prune_timeout=%d" % int(agg["prune_timeout"])) if int(agg["prune_timeout"]) > 0 else ""])
	print("=== 探针结束 ===")
	quit(0)
