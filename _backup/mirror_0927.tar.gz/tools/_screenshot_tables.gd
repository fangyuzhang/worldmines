extends Node

## 临时截图工具（tools/_*.gd 已 gitignore，不入库）：
## 自动导航到选关页，把「单项变体页 24 卡」+「混合档三张表」截成 PNG 落盘。
## 这补掉 B2 #6——此前只有 headless（截不了图），Godot-ai MCP 又连在 (Copy) 副本项目上，
## 唯有「场景方式正常启动」既有渲染又有完整 autoload。
##
## 跑法（必须非 headless）：
##   & $GODOT --path . res://tools/_screenshot_tables.tscn
## 产物：res://demo/web/preview_13_*.png / preview_14_*.png

const OUT := "res://demo/web"

func _ready() -> void:
	# 固定到设计分辨率（1280×720）：默认窗口尺寸不一定是设计值，观感验收必须在设计分辨率下做
	get_window().size = Vector2i(1280, 720)
	for i in 3:
		await get_tree().process_frame

	# 等 autoload 与首帧稳定
	for i in 5:
		await get_tree().process_frame

	var ls: Control = load("res://ui/level_select.tscn").instantiate()
	add_child(ls)
	for i in 8:
		await get_tree().process_frame

	# 单项变体页（经典 1 + 观测 10 + 结构守恒 13 + dt = 24 卡）
	ls.call("_show_tab", ls.PAGE_SINGLE)
	await _settle()
	_shot("preview_13_single_24cards.png")

	# 混合档三张表：C 类 70 / F 类 21 / T4 50
	ls.call("_show_tab", ls.PAGE_MIXED)
	await _settle()
	for tab in 3:
		ls.call("_on_mixed_switch", tab)
		await _settle()
		_shot("preview_14_mixed_tab%d.png" % tab)

	print("[shot] 全部完成")
	get_tree().quit()


func _settle() -> void:
	for i in 6:
		await get_tree().process_frame


func _shot(fname: String) -> void:
	var img := get_viewport().get_texture().get_image()
	var err: int = img.save_png("%s/%s" % [OUT, fname])
	print("[shot] %s → %s" % [fname, "OK" if err == OK else "ERR %d" % err])
