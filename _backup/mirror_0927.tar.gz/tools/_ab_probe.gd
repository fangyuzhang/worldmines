extends SceneTree

## A/B 探针（一次性诊断，不改生产形态）
##
## A 组（质量红线验证）：预算 probe_budget_ms = 0(旧行为) / 8s / 30s 对**难度画像**的影响。
##   若截断合法探测 → 少报强制格 → 删线索保守 → clue_count 升高、difficulty/max_complexity 下降。
##   判据：30s 应与 0（旧行为）逐项一致；8s 若明显更差，则 8s 属危险值。
## B 组（⑥ 吃满 2 核）：num_workers 1 vs 2 的耗时对比（其余不变）。

const MODS := ["s3_wuhuan", "o4_bianjing"]
const TIMEOUT_MS := 90_000

func _load_mods() -> void:
	for m in MODS:
		var entry := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(entry):
			var sc: Variant = load(entry)
			if sc != null:
				sc.new().call("on_load")

func _run(label: String, clue: String, globals: Array, side: int, mines: int,
		budget: int, workers: int, seeds: int) -> void:
	var gen := PuzzleGenerator.new()
	gen.probe_budget_ms = budget
	gen.num_workers = workers
	var hit := 0
	var clue_sum := 0
	var diff_sum := 0.0
	var mx := 0
	var vf := 0
	var pok := 0
	var pt := 0
	var t0 := Time.get_ticks_msec()
	for s in range(1, seeds + 1):
		var lv: Dictionary = gen.generate_with_rules(
			clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
		if not lv.is_empty():
			hit += 1
			var dp: Dictionary = lv.get("difficulty_profile", {})
			clue_sum += int(dp.get("clue_count", 0))
			diff_sum += float(dp.get("difficulty", 0.0))
			mx = maxi(mx, int(dp.get("max_complexity", 0)))
		vf += int(gen.last_call_stats.get("verify_fail", 0))
		pok += int(gen.last_call_stats.get("prune_ok", 0))
		pt += int(gen.last_call_stats.get("prune_timeout", 0))
	var dt := (Time.get_ticks_msec() - t0) / 1000.0
	var h := maxi(1, hit)
	print("%-30s %d/%d %7.2f %6.1f %6.2f %5d %6d %8d %8d" % [label, hit, seeds, dt / seeds,
		float(clue_sum) / h, diff_sum / h, mx, pok, vf, pt])

func _init() -> void:
	_load_mods()
	print("=== A 组：预算对难度画像的影响（s3@7，2 seed；clue/diff 越低=越简单=质量下降）===")
	print("cfg                              hit  avg_s  clue   diff  maxc  prune_ok  verifail  ptimeout")
	_run("s3@7 budget=0(旧行为)", "classic", ["s3"], 7, 20, 0, 1, 2)
	_run("s3@7 budget=8s", "classic", ["s3"], 7, 20, 8000, 1, 2)
	_run("s3@7 budget=30s(现行)", "classic", ["s3"], 7, 20, 30000, 1, 2)
	print("=== B 组：worker 数对耗时的影响（o4@6，3 seed；只比速度，质量项应一致）===")
	print("cfg                              hit  avg_s  clue   diff  maxc  prune_ok  verifail  ptimeout")
	_run("o4@6 workers=1", "o4", [], 6, 14, 0, 1, 3)
	_run("o4@6 workers=2", "o4", [], 6, 14, 0, 2, 3)
	print("=== A/B 结束 ===")
	quit(0)
