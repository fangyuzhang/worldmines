extends SceneTree

## 隐藏态契约审计（2026-09-27；r4 独立核验 N2 的**可复制**修法）。
##
## 为什么不能靠手写名单：计划原先写「按注册表枚举，含 o5b 缺 export/import 的漏洞」——
## 而 o5b 的 `declares()` 为空，用 `declares()["hidden_state"]` 作判据的枚举**必然漏掉它**，
## 恰恰漏掉的就是它要抓的那一个。且新 Mod 会不断出现，名单永远滞后。
##
## 本工具改用**状态依赖探针**（自证，不依赖任何名单）：
##   对每条 CLUE 规则，用两个不同 seed 在同一小盘上各跑一次 place_mines，
##   再对**同一个固定雷集**比较 compute_clue 的逐格输出。
##   · 输出随 seed 变化 ⇒ 该规则有隐藏态 ⇒ 必须同时满足三条：
##       ① declares()["hidden_state"] == true（生成器/审计据此知道它有状态）
##       ② export_hidden_state() 非空（落盘能带走）
##       ③ import(export()) 幂等（导出→清空→导入→再导出，逐字段一致）
##     任一不满足 ⇒ **FAIL**（该 Mod 会静默产出与自述不符的关，或存量无法回填）
##   · 输出不随 seed 变化 ⇒ 无隐藏态 ⇒ N/A（不算通过也不算失败）
##
## 覆盖 demo/mods 下**所有**目录（含 BUNDLED_SKIP——坑正是藏在默认不加载的那几个里；
## `--mods` 批产路径按目录名直载会绕过 skip）。用法：
##   & $GODOT --headless --path . -s res://tools/_hidden_state_audit.gd

const BOARD := 6        # 小盘（快）
const MINES := 10
const SEED_A := 111
const SEED_B := 222
const PROBE_POS := [Vector2i(2, 2), Vector2i(3, 2), Vector2i(2, 3), Vector2i(1, 1), Vector2i(4, 4)]


func _init() -> void:
	var dir := DirAccess.open("res://demo/mods")
	if dir == null:
		print("!! demo/mods 不可读")
		quit(1)
		return
	var loaded: Array = []
	var failed: Array = []
	for name in dir.get_directories():
		var p := "res://demo/mods/%s/entry.gd" % name
		if not ResourceLoader.exists(p):
			continue
		var sc: Variant = load(p)
		if sc == null:
			failed.append(name)
			continue
		sc.new().call("on_load")
		loaded.append(name)
	print("加载 mod 目录 %d 个（其中加载失败 %s）" % [loaded.size(), str(failed)])

	# 固定雷集（确定性）：只用于比较 compute_clue，不参与生成
	var mine_set := {}
	for i in MINES:
		mine_set[Vector2i(i % BOARD, i / BOARD)] = true

	var seen := {}
	var rows: Array = []
	for rid in RuleRegistry.default().ids() if RuleRegistry.default().has_method("ids") else []:
		pass
	# 注册表未提供 ids() 时，退化为「遍历已加载 mod 的规则 id」——从 rule 实例反查。
	var reg := RuleRegistry.default()
	var ids: Array = []
	if reg.has_method("ids"):
		ids = reg.call("ids")
	for m in loaded:
		var sc2: Variant = load("res://demo/mods/%s/entry.gd" % m)
		if sc2 == null:
			continue
		var inst: Variant = sc2.new()
		# 该 mod 注册了哪些 id：用「新建实例 → 反射 get_rule_id」不可靠（id 在内部类实例上），
		# 故改为：注册后从注册表按 mod 目录名猜不到——统一走全表探测（见下）。
		pass

	# 全表探测：候选 id = 全盘符号扫描不可行，改为「对已知 id 空间逐条 resolve」。
	# id 空间 = mod 目录名去掉语言后缀 + 常见内置别名（与 RuleSignature.table() 对齐）。
	var candidates: Array = []
	for m in loaded:
		candidates.append(m.split("_")[0])            # o1_duichuan -> o1；s3_wuhuan -> s3
		candidates.append("classic")
	var extra := ["o4", "o5x", "o5b", "pf", "mx", "ep", "rl", "qd", "dt", "4c", "grpk",
		"iso", "pair", "notri", "dense", "seg", "conn", "clock", "fr", "knight", "loopruns"]
	candidates.append_array(extra)
	candidates.sort()
	for rid in candidates:
		if seen.has(rid):
			continue
		seen[rid] = true
		var rule: Object = reg.resolve(StringName(str(rid)))
		if rule == null or rule.get_kind() != RulePlugin.KIND_CLUE:
			continue
		rows.append(_audit(str(rid), rule, mine_set))

	print("\n=== 隐藏态契约审计 ===")
	var bad: Array = []
	for r in rows:
		print("  %-8s %-6s state_dep=%-5s declares=%-5s export=%-2s idempotent=%-5s" % [
			r["id"], r["verdict"], str(r["state_dep"]), str(r["declares"]),
			str(r["export_card"]), str(r["idempotent"])])
		if r["verdict"] == "FAIL":
			bad.append(r["id"])
	print("__AUDIT__ 受审规则=%d  FAIL=%s" % [rows.size(), str(bad) if not bad.is_empty() else "无"])
	quit(1 if not bad.is_empty() else 0)


func _sig(rule: Object, mine_set: Dictionary) -> String:
	var out: Array = []
	for p in PROBE_POS:
		out.append(str(rule.call("compute_clue", mine_set, p, Vector2i(BOARD, BOARD))))
	return "|".join(out)


func _audit(rid: String, rule: Object, mine_set: Dictionary) -> Dictionary:
	# 两个 seed 各跑一次 place_mines → 同一固定雷集下的线索输出是否变化
	var rng_a := RandomNumberGenerator.new()
	rng_a.seed = SEED_A
	rule.call("place_mines", rng_a, BOARD, BOARD, MINES)
	var sig_a := _sig(rule, mine_set)
	var rng_b := RandomNumberGenerator.new()
	rng_b.seed = SEED_B
	rule.call("place_mines", rng_b, BOARD, BOARD, MINES)
	var sig_b := _sig(rule, mine_set)
	var state_dep := sig_a != sig_b
	if not state_dep:
		return {"id": rid, "verdict": "N/A", "state_dep": false, "declares": false,
			"export_card": 0, "idempotent": true}

	# ① declares
	var declares := false
	if rule.has_method("declares"):
		declares = bool((rule.call("declares") as Dictionary).get("hidden_state", false))
	# ② export 非空 + ③ import(export()) 幂等
	var st: Dictionary = rule.call("export_hidden_state") if rule.has_method("export_hidden_state") else {}
	var card := 0
	for k in st:
		if st[k] is Array:
			card += (st[k] as Array).size()
	var idem := false
	if not st.is_empty() and rule.has_method("import_hidden_state"):
		rule.call("import_hidden_state", {})                 # 清空
		rule.call("import_hidden_state", st)                 # 回填
		var st2: Dictionary = rule.call("export_hidden_state")
		idem = JSON.stringify(st2) == JSON.stringify(st)
	var ok := declares and card > 0 and idem
	return {"id": rid, "verdict": "PASS" if ok else "FAIL", "state_dep": true,
		"declares": declares, "export_card": card, "idempotent": idem}
