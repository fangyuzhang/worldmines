extends SceneTree

## Stage-0C 补测探针（只读；**不修改任何生产文件 core/ solver/ tools/batch_all_variants.gd tools/thin_cells.py test/**）
##
## 承接 stage0b 的 S2 / S3a / S3b（stage0b 只跑完 S1 就被运行时中断）。
## 口径严格对齐 team-lead 的补测要求：
##   S2  ProofLog.build 实测耗时：o1+s1@8x8/26 与 classic+s3@7x7/20 各 3 关，
##       每关用 Time.get_ticks_usec() 计 ProofLog.build；报平均 ms 与
##       proof / (t_place+t_prune+t_verify) 比值（batch_all_variants.gd:785 每个过关候选都跑它）。
##   S3a 多 G 布雷 t_place_ms：classic+s3+s4@8x8/26（先 RuleFeasibility.query 确认可行）3 seed，
##       报 t_place_ms 与 t_prune_ms 对比（globals>=2 → _find_solution_best 固定 7 次 build_spec+Solve）。
##   S3b o4 隐藏态正确性抽查：clue=o4、globals=[s1]、8x8/26 跑 3 seed，读产物 hidden_state 与
##       o4 实例 _r2，与应有值 _k_of(8,8)=floor(64*0.25)=16 对比；另做污染演示
##       （先 o4@8x8 无全局触发 place_mines → 再 o4+s1 → 看 _r2 是否残留同一集合）。
##
## 用法（项目根）：
##   & $GODOT --headless --path . -s res://tools/_stage0c_probe.gd            # 全部
##   ... -s res://tools/_stage0c_probe.gd -- s2 / s3a / s3b / s3
## 结果同时写 tools/_stage0c_out.txt（追加）。

const MODS := ["o1_duichuan", "s1_jinxing", "s2_zhongxin", "s3_wuhuan", "s4_yangcong", "o4_bianjing"]
const TIMEOUT_MS := 90_000
const LOG_PATH := "res://tools/_stage0c_out.txt"

var _log_file: FileAccess = null


func _log(s: String) -> void:
	print(s)
	if _log_file != null:
		_log_file.store_line(s)
		_log_file.flush()


func _load_mods() -> void:
	for m in MODS:
		var entry := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(entry):
			var sc: Variant = load(entry)
			if sc != null:
				sc.new().call("on_load")


func _init() -> void:
	if FileAccess.file_exists(LOG_PATH):
		_log_file = FileAccess.open(LOG_PATH, FileAccess.READ_WRITE)
		if _log_file != null:
			_log_file.seek_end()
	else:
		_log_file = FileAccess.open(LOG_PATH, FileAccess.WRITE)
	_load_mods()
	var args := OS.get_cmdline_user_args()
	var mode := "all"
	if args.size() > 0:
		mode = str(args[0]).to_lower()
	_log("")
	_log("=== Stage-0C 补测 mode=%s  引擎=%s ===" % [
		mode, str(Engine.get_version_info().get("string", "?"))])
	if mode == "all" or mode == "s2":
		_s2()
	if mode == "all" or mode == "s3a" or mode == "s3":
		_s3a()
	if mode == "all" or mode == "s3b" or mode == "s3":
		_s3b()
	_log("=== Stage-0C 探针结束 mode=%s ===" % mode)
	if _log_file != null:
		_log_file.close()
	quit(0)


# ==================== S2：ProofLog.build 实测（usec） ====================

func _s2_case(label: String, clue: String, globals: Array, side: int, mines: int, seeds: int) -> void:
	var tag := "[S2 %s %s+%s@%d/%d]" % [label, clue, str(globals), side, mines]
	var sum_proof_ms := 0.0
	var sum_internal_ms := 0.0
	var n := 0
	for s in range(1, seeds + 1):
		_log("%s seed=%d 生成中（clue=%s globals=%s mines=%d）..." % [tag, s, clue, str(globals), mines])
		var gen := PuzzleGenerator.new()
		var t0 := Time.get_ticks_msec()
		var lv: Dictionary = gen.generate_with_rules(
			clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
		var cost_ms := Time.get_ticks_msec() - t0
		if lv.is_empty():
			_log("%s seed=%d 生成失败 cost=%.2fs stats=%s" % [tag, s, cost_ms / 1000.0, str(gen.last_call_stats)])
			continue
		var st: Dictionary = gen.last_call_stats
		var place_ms := int(st.get("t_place_ms", 0))
		var prune_ms := int(st.get("t_prune_ms", 0))
		var verify_ms := int(st.get("t_verify_ms", 0))
		var internal_ms := place_ms + prune_ms + verify_ms
		var p0 := Time.get_ticks_usec()
		var plog: Dictionary = ProofLog.build(lv)
		var proof_us := Time.get_ticks_usec() - p0
		var proof_ms := float(proof_us) / 1000.0
		sum_proof_ms += proof_ms
		sum_internal_ms += float(internal_ms)
		n += 1
		_log("%s seed=%d cost=%.2fs internal(p+p+v)=%.2fs(place=%.2fs prune=%.2fs verify=%.2fs) proof=%.3fms(%.4fus) 占cost=%.1f%% 占internal=%.1f%% solved=%s" % [
			tag, s, cost_ms / 1000.0, internal_ms / 1000.0, place_ms / 1000.0, prune_ms / 1000.0,
			verify_ms / 1000.0, proof_ms, proof_us,
			100.0 * proof_ms / maxf(1.0, float(cost_ms)),
			100.0 * proof_ms / maxf(1.0, float(internal_ms)),
			str(plog.get("solved", false))])
	_log("%s 汇总: n=%d 平均 proof=%.3fms 平均 internal=%.1fms  比值 proof/internal=%.2f%%" % [
		tag, n, sum_proof_ms / maxf(1.0, float(n)), sum_internal_ms / maxf(1.0, float(n)),
		100.0 * sum_proof_ms / maxf(1.0, sum_internal_ms)])


func _s2() -> void:
	_log("")
	_log("=== S2：ProofLog.build 实测耗时（batch_all_variants.gd:785 每过关候选都跑）===")
	_s2_case("A-复合", "o1", ["s1"], 8, 26, 3)
	_s2_case("B-单席位", "classic", ["s3"], 7, 20, 3)


# ==================== S3a：多 G 布雷 t_place_ms ====================

func _s3a_case(label: String, clue: String, globals: Array, side: int, want_mines: int, seeds: int) -> void:
	var tag := "[S3a %s %s+%s@%d]" % [label, clue, str(globals), side]
	var feasible := RuleFeasibility.query(clue, globals, side, want_mines)
	var rr := RuleFeasibility.resolve_mines(clue, globals, side)
	_log("%s 目标雷数=%d 可行=%s | resolve_mines=%s | 候选=%s" % [
		tag, want_mines, str(feasible), str(rr), str(RuleFeasibility.CANDIDATES.get(side, []))])
	var mines := want_mines if feasible else int(rr["mines"])
	if mines < 0:
		_log("%s 无可行雷数（目标不可行且回退全 UNSAT），跳过" % tag)
		return
	if not feasible:
		_log("%s 目标 %d 不可行，回退到 resolve_mines=%d（结果仍可用，请注明雷数口径）" % [tag, want_mines, mines])
	for s in range(1, seeds + 1):
		_log("%s seed=%d 生成中（mines=%d）..." % [tag, s, mines])
		var gen := PuzzleGenerator.new()
		var t0 := Time.get_ticks_msec()
		var lv: Dictionary = gen.generate_with_rules(
			clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
		var dt := (Time.get_ticks_msec() - t0) / 1000.0
		var st: Dictionary = gen.last_call_stats
		var place_ms := int(st.get("t_place_ms", 0))
		var prune_ms := int(st.get("t_prune_ms", 0))
		_log("   %s seed=%d %s mines=%d 总=%.2fs t_place=%.2fs t_prune=%.2fs t_verify=%.2fs place/prune=%.2f attempts=%d brep_fail=%d prune_tries=%d" % [
			tag, s, "OK" if not lv.is_empty() else "MISS", mines, dt,
			place_ms / 1000.0, prune_ms / 1000.0, float(st.get("t_verify_ms", 0)) / 1000.0,
			float(place_ms) / maxf(1.0, float(prune_ms)),
			int(st.get("attempts", 0)), int(st.get("brep_fail", 0)), int(st.get("prune_tries", 0))])


func _s3a() -> void:
	_log("")
	_log("=== S3a：多 G 布雷 t_place_ms（globals>=2 → _find_solution_best 固定 7×build_spec+Solve）===")
	_s3a_case("2G经典+前2G", "classic", ["s3", "s4"], 8, 26, 3)
	_s3a_case("1G基线", "classic", ["s3"], 8, 26, 1)


# ==================== S3b：o4 隐藏态（_r2）正确性抽查 ====================

func _r2_keyset(o4: Object) -> Array:
	var ks: Array = []
	for k in (o4.get("_r2") as Dictionary).keys():
		ks.append(str(k))
	ks.sort()
	return ks


func _s3b_case(label: String, globals: Array, side: int, mines: int, seeds: int, clear_first: bool) -> void:
	var tag := "[S3b %s o4+%s@%d/%d]" % [label, str(globals), side, mines]
	var o4: Object = RuleRegistry.default().resolve(&"o4")
	if o4 == null:
		_log("%s o4 规则未注册，跳过" % tag)
		return
	var expect := int(o4.call("_k_of", side, side))
	_log("%s 期望 _k_of(%d,%d)=%d（k_ratio=%.2f）  clear_first=%s" % [
		tag, side, side, expect, float(o4.call("get_k_ratio")), str(clear_first)])
	if clear_first:
		o4.call("import_hidden_state", {})
	var first_set: Array = []
	for s in range(1, seeds + 1):
		var before := (o4.get("_r2") as Dictionary).size()
		_log("   %s seed=%d 生成中（before_r2=%d）..." % [tag, s, before])
		var gen := PuzzleGenerator.new()
		var lv: Dictionary = gen.generate_with_rules(
			"o4", globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
		var st: Dictionary = gen.last_call_stats
		var after := (o4.get("_r2") as Dictionary).size()
		var hs_r2 := -1
		var hs_keyset: Array = []
		if not lv.is_empty():
			var hsd: Dictionary = lv.get("hidden_state", {})
			var o4s: Dictionary = hsd.get("o4", {})
			var arr: Array = o4s.get("r2", [])
			hs_r2 = arr.size()
			for it in arr:
				hs_keyset.append(str(Vector2i(int(it["c"]), int(it["r"]))))
			hs_keyset.sort()
		var cur := _r2_keyset(o4)
		if s == 1:
			first_set = cur
		var same_as_first := (cur == first_set)
		_log("   %s seed=%d %s 实例_r2: before=%d after=%d 落盘hidden_state.o4.r2=%d  vs期望%d | 与seed1同集=%s verify_fail=%d brep_fail=%d prune_empty=%d" % [
			tag, s, "OK" if not lv.is_empty() else "MISS", before, after, hs_r2, expect,
			str(same_as_first), int(st.get("verify_fail", 0)), int(st.get("brep_fail", 0)),
			int(st.get("prune_empty", 0))])
		if hs_r2 >= 0 and hs_r2 != expect:
			_log("   %s seed=%d ！！落盘隐藏态基数 %d != 期望 %d" % [tag, s, hs_r2, expect])
	o4.call("import_hidden_state", {})


func _s3b() -> void:
	_log("")
	_log("=== S3b：o4 隐藏态 _r2 正确性抽查（单 G 分支早返回 ⇒ clue.place_mines 不执行）===")
	var m := 26
	var ok := RuleFeasibility.query("o4", ["s1"], 8, m)
	_log("o4+s1@8x8 目标雷数 %d 可行=%s | resolve_mines=%s" % [
		m, str(ok), str(RuleFeasibility.resolve_mines("o4", ["s1"], 8))])
	if not ok:
		m = int(RuleFeasibility.resolve_mines("o4", ["s1"], 8)["mines"])
		_log("目标 26 不可行，回退 mines=%d（结果请注明雷数口径）" % m)
	if m < 0:
		_log("o4+s1@8x8 全 UNSAT，S3b 跳过")
		return
	_s3b_case("清空后", ["s1"], 8, m, 3, true)

	# 污染演示：先跑 o4@8x8（无全局 → 单 G 无 s* → o4.place_mines 执行 → _r2=16），
	# 再跑 o4+s1@8x8（线索规则的 place_mines 被跳过 → _r2 保留上一块盘的值）。
	_log("--- 污染演示：先 o4@8x8（无全局，触发 o4.place_mines）→ 再 o4+s1@8x8 ---")
	var o4: Object = RuleRegistry.default().resolve(&"o4")
	o4.call("import_hidden_state", {})
	var g := PuzzleGenerator.new()
	var lv0: Dictionary = g.generate_with_rules("o4", [], Vector2i(8, 8), 26, 1, 0, 1, null, TIMEOUT_MS)
	var contaminated := _r2_keyset(o4)
	_log("   o4@8x8(无全局) %s → 实例 _r2=%d" % [
		"OK" if not lv0.is_empty() else "MISS", contaminated.size()])
	_s3b_case("污染后", ["s1"], 8, m, 3, false)
	var o4b: Object = RuleRegistry.default().resolve(&"o4")
	var after := _r2_keyset(o4b)
	_log("   污染演示结论: o4+s1 跑完后 _r2=%d，与 o4@8x8 同集=%s（同集即证明线索规则 place_mines 未执行、隐藏态陈旧）" % [
		after.size(), str(after == contaminated)])
	o4b.call("import_hidden_state", {})
