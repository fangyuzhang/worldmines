extends SceneTree

## P0 收尾验收（2026-09-27）：新复合档的**独立** ProofLog 抽样复核 + 落盘。
##
## 为什么必须独立复核（r4 N4）：生成器内建验证（`_solve_rules_stepwise`）与线索值都读**同一个
## 注册表单例状态**，是自洽检查；`ProofLog.build` 是「玩家视角 + HintSolver」的**另一套模型**，
## 目前唯一独立于生成器的复核。P0 改了隐藏态初始化，必须确认新盘在独立模型下也能推到底。
##
## 产物：res://_staged_levels/p0_proof/<combo>_s<seed>.json（供 verify_batch 走完整门禁）。
## 用法：& $GODOT --headless --path . -s res://tools/_p0_proof.gd

const MODS := ["o4_bianjing", "o5_xiemai", "s3_wuhuan", "s1_jinxing"]
const OUT_DIR := "res://_staged_levels/p0_proof"
## [clue, globals, side, mines, 标签]
const CASES := [
	["o4", ["s1"], 8, 26, "o4+s1@8"],    # P0 修复域
	["o5x", ["s1"], 7, 20, "o5x+s1@7"],  # P0 修复域
	["o4", [], 8, 26, "o4@8"],           # 对照：单线索档（P0 前后逐字节一致）
]
const SEEDS := 2


func _init() -> void:
	for m in MODS:
		var p := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(p):
			load(p).new().call("on_load")
	DirAccess.make_dir_recursive_absolute(OUT_DIR)
	var pass_n := 0
	var fail_n := 0
	for c in CASES:
		for s in range(1, SEEDS + 1):
			var tag := "%s" % c[4]
			var gen := PuzzleGenerator.new()
			var lv: Dictionary = gen.generate_with_rules(
				c[0], c[1], Vector2i(c[2], c[2]), int(c[3]), s, 0, 1, null, 90000)
			if lv.is_empty():
				print("[%s] seed %d 空返回 stats=%s" % [tag, s, JSON.stringify(gen.last_call_stats)])
				fail_n += 1
				continue
			var path := "%s/%s_s%d.json" % [OUT_DIR, tag, s]
			var wf := FileAccess.open(path, FileAccess.WRITE)
			wf.store_string(JSON.stringify(lv, "  "))
			wf.close()
			var lg: Dictionary = ProofLog.build(lv)
			var ok := bool(lg.get("solved", false))
			if ok:
				pass_n += 1
			else:
				fail_n += 1
			print("__PROOF__ %-10s s%d solved=%-5s rounds=%-3s hs=%s reason=%s" % [
				tag, s, str(ok), str(lg.get("rounds", -1)), _hs_summary(lv), str(lg.get("reason", ""))])
	print("=== 独立 ProofLog 抽样复核：solved=%d  failed=%d  （产物在 %s）===" % [pass_n, fail_n, OUT_DIR])
	quit(0)


func _hs_summary(lv: Dictionary) -> String:
	var hs: Dictionary = lv.get("hidden_state", {})
	var out: Array = []
	for k in hs:
		var st: Dictionary = hs[k]
		for sk in st:
			out.append("%s.%s=%d" % [str(k), str(sk), (st[sk] as Array).size()])
	return "{" + ",".join(out) + "}" if not out.is_empty() else "{}"
