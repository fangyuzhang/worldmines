extends SceneTree

## Stage-0B 追加测量探针（只读；**不修改任何生产文件**）
##
## 由 plan-auditor 的 3 条审计项驱动（"只有测量侧能补的数"）：
##   S1  删线索每 try 的「轮数 / 每轮 build_spec vs find_forced_cells 实测拆分」——
##       忠实复制 puzzle_generator._solve_rules_stepwise 的主体（同 build_spec + 同
##       RuleCpSat.find_forced_cells + 同 probe_budget_ms 口径），逐轮用 Time.get_ticks_usec()
##       计时，得到「IR 组装 vs C# Solve」的**实测**占比（替代 M1 的「×10 轮」粗估）。
##       轮数 = 该 try 内的序贯演绎步数 = find_forced_cells 调用次数；
##       每轮自由格数 f ≈ 该轮 C# 侧 assumption 探测次数（Solve 次数）→ 给出 est Solve 总数。
##   S2  ProofLog.build 实测耗时（batch_all_variants.gd:785 每个过关候选都跑它，
##       而 _phase_probe/_stage0_probe 完全绕过）→ 与 cost_s / (t_place+t_prune+t_verify) 对账。
##   S3a 多 G 布雷 t_place_ms（globals≥2 走 _find_solution_best：7 次 build_spec + 7 次 Solve）。
##   S3b o4 隐藏态（_r2）在「带全局规则」时的正确性抽查：已知单 G 分支在
##       `if not m.is_empty(): return m`（:726-729）早返回 ⇒ clue 规则的 place_mines 不执行。
##
## 用法（项目根）：
##   & $GODOT --headless --path . -s res://tools/_stage0b_probe.gd            # 全部
##   & $GODOT --headless --path . -s res://tools/_stage0b_probe.gd -- s1      # 只 S1
##   ... s2 / s3

const MODS := ["o1_duichuan", "s1_jinxing", "s2_zhongxin", "s3_wuhuan", "s4_yangcong", "o4_bianjing"]
const TIMEOUT_MS := 90_000
const LOG_PATH := "res://tools/_stage0b_out.txt"

var _log_file: FileAccess = null


func _log(s: String) -> void:
	print(s)
	if _log_file != null:
		_log_file.store_line(s)
		_log_file.flush()


func _load_mods() -> void:
	for m in MODS:
		var entry := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(entry):
			var sc: Variant = load(entry)
			if sc != null:
				sc.new().call("on_load")


func _resolve_globals(ids: Array) -> Array:
	var reg := RuleRegistry.default()
	var out: Array = []
	for gid in ids:
		var g: Object = reg.resolve(StringName(str(gid)))
		if g != null:
			out.append(g)
	return out


func _mine_set(level: Dictionary) -> Dictionary:
	var ms := {}
	for m in level.get("mines", []):
		ms[Vector2i(int(m["c"]), int(m["r"]))] = true
	return ms


## 全线索集（生成器删线索前的 active 口径：全部非雷且 applies_to 的格）。
func _all_values(level: Dictionary, clue: String, side: int) -> Dictionary:
	var rule: Object = RuleRegistry.default().resolve(StringName(clue))
	var ms := _mine_set(level)
	var size := Vector2i(side, side)
	var values := {}
	for r in side:
		for c in side:
			var p := Vector2i(c, r)
			if ms.has(p):
				continue
			if not rule.applies_to(p, size):
				continue
			values[p] = rule.compute_clue(ms, p, size)
	return values


func _init() -> void:
	_log_file = FileAccess.open(LOG_PATH, FileAccess.WRITE)
	_load_mods()
	var args := OS.get_cmdline_user_args()
	var mode := "all"
	if args.size() > 0:
		mode = str(args[0]).to_lower()
	_log("=== Stage-0B 追加测量 mode=%s ===" % mode)
	if mode == "all" or mode == "s1":
		_s1()
	if mode == "all" or mode == "s2":
		_s2()
	if mode == "all" or mode == "s3":
		_s3a()
		_s3b()
	_log("=== 探针结束 ===")
	if _log_file != null:
		_log_file.close()
	quit(0)


# ==================== S1：每 try 的轮数 / 组装 vs Solve 实测拆分 ====================

## 忠实复制 `_prune_clues_rules` + `_prune_sequential` + `_solve_rules_stepwise` 主体，
## 但逐轮插桩计时。**判据与顺序均取自生产实现**（_prune_less 直接 call 生产方法）。
func _s1_case(label: String, clue: String, globals: Array, side: int, mines: int) -> void:
	var tag := "[S1 %s %s+%s@%d/%d]" % [label, clue, str(globals), side, mines]
	var t_case0 := Time.get_ticks_msec()
	var gen0 := PuzzleGenerator.new()
	var lv: Dictionary = gen0.generate_with_rules(
		clue, globals, Vector2i(side, side), mines, 1, 0, 1, null, TIMEOUT_MS)
	if lv.is_empty():
		_log("%s 生成失败，跳过（last_call_stats=%s）" % [tag, str(gen0.last_call_stats)])
		return
	var total_mines := int(lv.get("total_mines", mines))
	var values := _all_values(lv, clue, side)
	var oracle := RuleOracle.new(
		RuleRegistry.default().resolve(StringName(clue)), _resolve_globals(globals),
		Vector2i(side, side), total_mines, null)
	# 生产口径的删除候选顺序：跳过 0 值格（puzzle_generator.gd:808-815）+ prune_less 排序
	var active: Dictionary = values.duplicate()
	var keys: Array = []
	for p in active:
		if values[p] is int and int(values[p]) == 0:
			continue
		keys.append(p)
	keys.sort_custom(func(a, b) -> bool: return gen0.call("_prune_less", a, b, values, active))

	var deadline := Time.get_ticks_msec() + TIMEOUT_MS
	var tries := 0
	var ok := 0
	var rounds_total := 0
	var free_total := 0
	var sum_build_us := 0
	var sum_force_us := 0
	var applies := 0
	var tries_full_solved := 0
	var t_prune0 := Time.get_ticks_msec()
	for p in keys:
		if Time.get_ticks_msec() > deadline:
			_log("%s 墙钟触界，提前停止删除循环" % tag)
			break
		if active.size() <= 1:
			break
		applies += 1
		tries += 1
		var backup: Variant = active[p]
		active.erase(p)
		# ---- _solve_rules_stepwise 主体（生产同款调用）----
		var cur := active.duplicate()
		var known: Array[Vector2i] = []
		var solved := false
		var steps := 0
		while cur.size() + known.size() < side * side:
			steps += 1
			if steps > side * side + 8:
				break
			var free_n := side * side - cur.size() - known.size()
			var b0 := Time.get_ticks_usec()
			var spec: Dictionary = oracle.build_spec(cur, known, {})
			var b1 := Time.get_ticks_usec()
			if deadline > 0:
				var remain := deadline - Time.get_ticks_msec()
				if remain <= 0:
					break
				spec["probe_budget_ms"] = clampi(remain, 500, maxi(500, oracle.probe_budget_ms))
			var forced: Dictionary = RuleCpSat.find_forced_cells(spec)
			var b2 := Time.get_ticks_usec()
			rounds_total += 1
			free_total += free_n
			sum_build_us += b1 - b0
			sum_force_us += b2 - b1
			var progressed := false
			for m in forced.get("mine", []):
				var pos := Vector2i(int(m[1]), int(m[0]))
				if not known.has(pos):
					known.append(pos)
					progressed = true
			for s in forced.get("safe", []):
				var pos2 := Vector2i(int(s[1]), int(s[0]))
				if not cur.has(pos2):
					cur[pos2] = values.get(pos2, null)
					progressed = true
			if not progressed:
				break
			if cur.size() + known.size() >= side * side:
				solved = true
		if solved:
			ok += 1
			tries_full_solved += 1
		else:
			active[p] = backup
	var prune_s := (Time.get_ticks_msec() - t_prune0) / 1000.0
	var tot_us := sum_build_us + sum_force_us
	var build_pct := 100.0 * float(sum_build_us) / maxf(1.0, float(tot_us))
	var per_round_force := float(sum_force_us) / maxf(1.0, float(rounds_total)) / 1000.0
	_log("%s 删除试探=%d（候选 %d，ok=%d） prune 墙钟=%.2fs" % [tag, tries, applies, ok, prune_s])
	_log("   轮数(build_spec=find_forced_cells 调用数)=%d  轮/try=%.1f  自由格累计=%d（均 %.1f/轮）" % [
		rounds_total, float(rounds_total) / maxf(1.0, float(tries)), free_total,
		float(free_total) / maxf(1.0, float(rounds_total))])
	_log("   实测拆分: build_spec 累计 %.1fms (%.1f%%) | find_forced_cells 累计 %.1fms (%.1f%%)   [单轮 find_forced≈%.1fms]" % [
		float(sum_build_us) / 1000.0, build_pct, float(sum_force_us) / 1000.0, 100.0 - build_pct, per_round_force])
	_log("   推算 C# Solve 次数 ≈ 自由格累计 %d（每轮 O(自由格) 次 assumption 探测）→ ≈%.2fms/Solve" % [
		free_total, float(sum_force_us) / 1000.0 / maxf(1.0, float(free_total))])
	_log("   口径核对: 生产 gen.last_call_stats.t_prune_ms(首个 seed)=%dms  本复制循环 prune=%.0fms" % [
		int(gen0.last_call_stats.get("t_prune_ms", 0)), prune_s * 1000.0])
	_log("   墙钟 %.1fs" % [(Time.get_ticks_msec() - t_case0) / 1000.0])


func _s1() -> void:
	_log("")
	_log("=== S1：删线索每 try 的轮数 + 组装/Solve 实测拆分 ===")
	_s1_case("A-复合", "o1", ["s1"], 8, 26)
	_s1_case("B-单席位", "classic", ["s3"], 7, 20)


# ==================== S2：ProofLog.build 实测 ====================

func _s2_case(label: String, clue: String, globals: Array, side: int, mines: int, seeds: int) -> void:
	var tag := "[S2 %s %s+%s@%d/%d]" % [label, clue, str(globals), side, mines]
	for s in range(1, seeds + 1):
		var gen := PuzzleGenerator.new()
		var t0 := Time.get_ticks_msec()
		var lv: Dictionary = gen.generate_with_rules(
			clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
		var cost_ms := Time.get_ticks_msec() - t0
		if lv.is_empty():
			_log("%s seed=%d 生成失败 cost=%.2fs" % [tag, s, cost_ms / 1000.0])
			continue
		var st: Dictionary = gen.last_call_stats
		var internal_ms := int(st.get("t_place_ms", 0)) + int(st.get("t_prune_ms", 0)) + int(st.get("t_verify_ms", 0))
		var p0 := Time.get_ticks_msec()
		var log: Dictionary = ProofLog.build(lv)
		var proof_ms := Time.get_ticks_msec() - p0
		_log("%s seed=%d cost=%.2fs internal(place+prune+verify)=%.2fs proof=%.2fs(%.1f%% of cost) solved=%s rounds=%d" % [
			tag, s, cost_ms / 1000.0, internal_ms / 1000.0, proof_ms / 1000.0,
			100.0 * float(proof_ms) / maxf(1.0, float(cost_ms)), str(log.get("solved", false)),
			int(log.get("rounds", 0))])


func _s2() -> void:
	_log("")
	_log("=== S2：ProofLog.build 实测（batch:785 每过关候选都跑）===")
	_s2_case("A-复合", "o1", ["s1"], 8, 26, 2)
	_s2_case("B-单席位", "classic", ["s3"], 7, 20, 2)
	_s2_case("单算子", "o4", [], 6, 14, 2)


# ==================== S3a：多 G 布雷 t_place ====================

func _s3a_case(label: String, clue: String, globals: Array, side: int, seeds: int) -> void:
	var tag := "[S3a %s %s+%s@%d]" % [label, clue, str(globals), side]
	var rr := RuleFeasibility.resolve_mines(clue, globals, side)
	var mines := int(rr["mines"])
	if mines < 0:
		_log("%s 候选雷数全不可行（UNSAT），跳过" % tag)
		return
	_log("%s 采用雷数=%d（候选 %s）" % [tag, mines, str(RuleFeasibility.CANDIDATES.get(side, []))])
	for s in range(1, seeds + 1):
		var gen := PuzzleGenerator.new()
		var t0 := Time.get_ticks_msec()
		var lv: Dictionary = gen.generate_with_rules(
			clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
		var dt := (Time.get_ticks_msec() - t0) / 1000.0
		var st: Dictionary = gen.last_call_stats
		_log("   %s seed=%d %s 总=%.2fs t_place=%.2fs t_prune=%.2fs t_verify=%.2fs attempts=%d brep_fail=%d" % [
			tag, s, "OK" if not lv.is_empty() else "MISS", dt,
			float(st.get("t_place_ms", 0)) / 1000.0, float(st.get("t_prune_ms", 0)) / 1000.0,
			float(st.get("t_verify_ms", 0)) / 1000.0, int(st.get("attempts", 0)), int(st.get("brep_fail", 0))])


func _s3a() -> void:
	_log("")
	_log("=== S3a：多 G 布雷 t_place_ms（globals>=2 → _find_solution_best：7×build_spec + 7×Solve）===")
	_s3a_case("1G 基线", "classic", ["s1"], 8, 2)
	_s3a_case("2G-F类", "classic", ["s1", "s2"], 8, 3)
	_s3a_case("2G-F类", "classic", ["s3", "s4"], 8, 3)


# ==================== S3b：o4 隐藏态（_r2）正确性抽查 ====================

func _o4_rule() -> Object:
	return RuleRegistry.default().resolve(&"o4")


func _s3b_case(label: String, globals: Array, side: int, mines: int, seeds: int, clear_first: bool) -> void:
	var tag := "[S3b %s o4+%s@%d/%d]" % [label, str(globals), side, mines]
	var o4: Object = _o4_rule()
	if o4 == null:
		_log("%s o4 规则未注册，跳过" % tag)
		return
	if clear_first:
		o4.call("import_hidden_state", {})   # 清空单例 _r2 → 模拟「全新会话」口径
	var expect := int(floor(float(side * side) * 0.25))
	_log("%s 期望 r2 数量=%d（side²×0.25）；clear_first=%s" % [tag, expect, str(clear_first)])
	var empties := 0
	var verify_fail := 0
	var brep_fail := 0
	var prune_empty := 0
	for s in range(1, seeds + 1):
		var live_before := (o4.get("_r2") as Dictionary).size()
		var gen := PuzzleGenerator.new()
		var lv: Dictionary = gen.generate_with_rules(
			"o4", globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
		var st: Dictionary = gen.last_call_stats
		verify_fail += int(st.get("verify_fail", 0))
		brep_fail += int(st.get("brep_fail", 0))
		prune_empty += int(st.get("prune_empty", 0))
		var r2_live := (o4.get("_r2") as Dictionary).size()
		var hs_size := -1
		var lvl := -1
		if not lv.is_empty():
			lvl = int(lv["difficulty_profile"].get("clue_count", -1))
			var hs: Dictionary = lv.get("hidden_state", {})
			var o4s: Dictionary = hs.get("o4", {})
			hs_size = (o4s.get("r2", []) as Array).size()
		else:
			empties += 1
		_log("   %s seed=%d %s r2(生成前=%d, 生成后=%d, 落盘=%d) clue=%d verify_fail=%d brep_fail=%d" % [
			tag, s, "OK" if not lv.is_empty() else "MISS", live_before, r2_live, hs_size, lvl,
			int(st.get("verify_fail", 0)), int(st.get("brep_fail", 0))])
	_log("%s 汇总: 空返回=%d/%d verify_fail=%d brep_fail=%d prune_empty=%d" % [
		tag, empties, seeds, verify_fail, brep_fail, prune_empty])
	o4.call("import_hidden_state", {})   # 复位，避免污染后续用例


func _s3b() -> void:
	_log("")
	_log("=== S3b：o4 隐藏态 _r2 在带全局规则时的正确性抽查（单 G 分支早返回不跑 clue.place_mines）===")
	var m6 := RuleFeasibility.resolve_mines("o4", ["s1"], 6)
	var m8 := RuleFeasibility.resolve_mines("o4", ["s1"], 8)
	_log("o4+s1 采用雷数: 6x6=%d  8x8=%d（候选 %s / %s）" % [
		int(m6["mines"]), int(m8["mines"]),
		str(RuleFeasibility.CANDIDATES.get(6, [])), str(RuleFeasibility.CANDIDATES.get(8, []))])
	if int(m6["mines"]) < 0 or int(m8["mines"]) < 0:
		_log("o4+s1 存在 UNSAT 尺寸，S3b 跳过")
		return
	_s3b_case("全新(清空 r2)", ["s1"], 6, int(m6["mines"]), 10, true)
	_s3b_case("全新(清空 r2)", ["s1"], 8, int(m8["mines"]), 3, true)
	# 残留污染演示：先跑一次无全局的 o4@8×8（o4.place_mines 会执行 → _r2=16），
	# 再跑 o4+s1@6×6（clue.place_mines 不执行 → _r2 保持 16 的 8×8 坐标）
	_log("--- 残留污染演示：先 o4@8×8（无全局，触发 o4.place_mines）→ 再 o4+s1@6×6 ---")
	var o4: Object = _o4_rule()
	o4.call("import_hidden_state", {})
	var g := PuzzleGenerator.new()
	var lv0: Dictionary = g.generate_with_rules("o4", [], Vector2i(8, 8), 26, 1, 0, 1, null, TIMEOUT_MS)
	_log("   o4@8x8(无全局) %s → _r2=%d" % [
		"OK" if not lv0.is_empty() else "MISS", (o4.get("_r2") as Dictionary).size()])
	_s3b_case("污染后", ["s1"], 6, int(m6["mines"]), 3, false)
