# 存量盘 hidden_state 回填（2026-09-16，配合 HANDOFF 已知坑 #18 修复）
# 对目录逐盘：
#   1) 读盘；已有 hidden_state → 跳过；
#   2) 同 seed 重放 place_mines 恢复隐藏态（≤40 attempt 匹配 mines）；
#   3) export_hidden_state → 写回 JSON（同款格式 JSON.stringify(level, "  ")）。
# 无构造式布雷输出（默认 place_mines）的规则 → 跳过（不适用重放恢复）。
# 用法：godot --headless --path . -s res://tools/_backfill_hidden_state.gd -- <dir> [--dry]
extends SceneTree

const CliShutdown := preload("res://tools/cli_shutdown.gd")

var _dry := false
var _skip_has := 0
var _skip_plain := 0
var _replay_fail := 0
var _written := 0


func _initialize() -> void:
	var mods_dir := DirAccess.open("res://demo/mods")
	if mods_dir != null:
		for sub in mods_dir.get_directories():
			var entry := "res://demo/mods/%s/entry.gd" % sub
			if ResourceLoader.exists(entry):
				var sc: Variant = load(entry)
				if sc != null:
					sc.new().call("on_load")
	var args := OS.get_cmdline_user_args()
	var dir_path := "res://_staged_levels/harvest_0915b/batch_o5x"
	if args.size() > 0:
		dir_path = str(args[0])
	_dry = args.has("--dry")
	var files := _list_json(dir_path)
	print("回填 %s 共 %d 盘（dry=%s）" % [dir_path, files.size(), _dry])
	var t0 := Time.get_ticks_msec()
	for i in files.size():
		_backfill(files[i])
		if (i + 1) % 100 == 0:
			print("  进度 %d/%d written=%d skipped=%d fail=%d elapsed=%ds" % [
				i + 1, files.size(), _written, _skip_has + _skip_plain, _replay_fail,
				(Time.get_ticks_msec() - t0) / 1000])
	print("=== 汇总 === 总=%d 已含字段=%d 不适用=%d 重放失败=%d 已写=%d" % [
		files.size(), _skip_has, _skip_plain, _replay_fail, _written])
	CliShutdown.request_exit(0)


func _backfill(path: String) -> void:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return
	var level: Dictionary = JSON.parse_string(f.get_as_text())
	f.close()
	if level.is_empty():
		return
	if level.has("hidden_state"):
		_skip_has += 1
		return
	var clue_id := str(level.get("clue_rule", ""))
	var rule: Object = RuleRegistry.default().resolve(StringName(clue_id))
	if rule == null or not rule.has_method("place_mines") or not rule.has_method("export_hidden_state"):
		_skip_plain += 1
		return
	var size: Dictionary = level.get("size", {})
	var rows := int(size.get("rows", 0))
	var cols := int(size.get("cols", 0))
	var seed_v := int(level.get("seed", 0))
	var mc := int(level.get("total_mines", 0))
	var mine_set := {}
	for m in level.get("mines", []):
		mine_set[Vector2i(int(m["c"]), int(m["r"]))] = true
	var matched := false
	var any_output := false
	for attempt in 40:
		var rng := RandomNumberGenerator.new()
		rng.seed = seed_v * 1000003 + attempt
		var mines: Array = rule.call("place_mines", rng, cols, rows, mc)
		if not mines.is_empty():
			any_output = true
		var s := {}
		for m in mines:
			s[m] = true
		var same := s.size() == mine_set.size()
		if same:
			for k in s:
				if not mine_set.has(k):
					same = false
					break
		if same:
			matched = true
			break
	if not matched:
		if any_output:
			_replay_fail += 1
			print("  重放失败: %s" % path)
		else:
			_skip_plain += 1  # 默认 place_mines（无构造式布雷）——不适用重放
		return
	var st: Dictionary = rule.call("export_hidden_state")
	if st.is_empty():
		_skip_plain += 1
		return
	level["hidden_state"] = {clue_id: st}
	if not _dry:
		var wf := FileAccess.open(path, FileAccess.WRITE)
		if wf == null:
			print("  写入失败: %s" % path)
			return
		wf.store_string(JSON.stringify(level, "  "))
		wf.close()
	_written += 1


func _process(_delta: float) -> bool:
	return CliShutdown.poll(self)


func _list_json(dir_path: String) -> Array[String]:
	var out: Array[String] = []
	var dir := DirAccess.open(dir_path)
	if dir == null:
		return out
	dir.list_dir_begin()
	var n := dir.get_next()
	while n != "":
		if dir.current_is_dir():
			out.append_array(_list_json(dir_path.path_join(n)))
		elif n.ends_with(".json") and not n.begins_with("all_report"):
			out.append(dir_path.path_join(n))
		n = dir.get_next()
	dir.list_dir_end()
	out.sort()
	return out
