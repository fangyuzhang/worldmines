$g = 'D:\Godot.NET\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64_console.exe'
$root = 'C:\Users\zjh30\CodeBuddy\20260906184916'
# 全量门禁：JSON 解析 / Board 引擎真实构造加载 / R07 固定雷数 / schema / 线索值 round-trip / ProofLog 序贯可解
$p = Start-Process -FilePath $g -ArgumentList '--headless','--path','.','-s','res://tools/verify_batch.gd','--','res://_staged_levels/p0_proof' -WorkingDirectory $root -RedirectStandardOutput "$root\tools\_vb_p0.log" -RedirectStandardError "$root\tools\_vb_p0.err" -NoNewWindow -PassThru
"VB_PID=$($p.Id)"
