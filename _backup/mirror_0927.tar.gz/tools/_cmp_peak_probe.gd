extends SceneTree

## 复合档峰值可达性探针（一次性诊断，不改生产）
##
## 问题：复合计划会排出 141 条 hard（6-20）轮。若复合组合的峰值（max_complexity）
## 结构性达不到 6+，这些轮会像 o8/o9/dt 一样白烧机时。
## 参考基线（单席位已实测）：s3@7 maxc=8、o4@6 maxc=9 ⇒ 单席位 hard 可达。
##
## 逐 seed 打印（避免长跑被外层空闲超时打断），可后台执行后轮询日志。

const MODS := ["o1_duichuan", "s1_jinxing", "s2_zhongxin", "s3_wuhuan"]
const TIMEOUT_MS := 90_000

const CASES := [
	["o1", ["s1"], 7, 20, "C类 s1_o1@7"],
	["o1", ["s1"], 9, 32, "C类 s1_o1@9"],
]

func _init() -> void:
	for m in MODS:
		var entry := "res://demo/mods/%s/entry.gd" % m
		if ResourceLoader.exists(entry):
			var sc: Variant = load(entry)
			if sc != null:
				sc.new().call("on_load")
	print("=== 复合峰值可达性（逐 seed）===")
	for c in CASES:
		var clue: String = c[0]
		var globals: Array = c[1]
		var side: int = c[2]
		var mines: int = c[3]
		var label: String = c[4]
		if not PuzzleGenerator.precheck_rules(clue, globals, Vector2i(side, side), mines)["ok"]:
			print("%-14s UNSAT（预筛拒绝）" % label)
			continue
		var gen := PuzzleGenerator.new()
		var hist := {}
		for s in range(1, 4):
			var t0 := Time.get_ticks_msec()
			var lv: Dictionary = gen.generate_with_rules(
				clue, globals, Vector2i(side, side), mines, s, 0, 1, null, TIMEOUT_MS)
			var dt := (Time.get_ticks_msec() - t0) / 1000.0
			if lv.is_empty():
				print("%-14s seed=%d  空返回  %.1fs  %s" % [label, s, dt,
					JSON.stringify(gen.last_call_stats)])
				continue
			var dp: Dictionary = lv.get("difficulty_profile", {})
			var pk := int(dp.get("max_complexity", -1))
			hist[pk] = int(hist.get(pk, 0)) + 1
			print("%-14s seed=%d  peak=%d  clue=%d  diff=%.2f  %.1fs" % [
				label, s, pk, int(dp.get("clue_count", 0)), float(dp.get("difficulty", 0.0)), dt])
		var ks: Array = hist.keys()
		ks.sort()
		var hs: Array = []
		for k in ks:
			hs.append("%d:%d" % [int(k), int(hist[k])])
		print("%-14s 汇总 peak 直方图 = %s" % [label, ",".join(hs)])
	print("=== 探针结束 ===")
	quit(0)
