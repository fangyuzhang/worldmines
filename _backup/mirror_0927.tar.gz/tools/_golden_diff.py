#!/usr/bin/env python3
"""golden 快照独立只读比对（P0 验收工具，2026-09-27）。

为什么必须独立于 tools/_golden_snapshot.gd：
  · 该脚本以 FileAccess.WRITE 打开产物——**手动重跑即销毁基线**，比对不能靠它；
  · 它只输出「本次」快照，无法回答「P0 前后哪些变了、哪些必须没变」。

判据（来自 r4 独立核验的 N1/§2 与 P0 探针实测）：
  1. **逐元素**比对，不得只比基数：mines / revealed / hidden_state.*.coords 全要比。
     （同尺寸陈旧态能通过「基数 + 坐标在图内」这两条弱断言——实测污染后
       before=16 after=16、与 seed1 同集、verify_fail=0，全部通过。）
  2. 计时类字段（seed_ms / last_call_stats / 墙钟派生）不参与判定——删线索按墙钟判停，
     重跑本就有波动（已文档化的残余风险），拿它判回归会天天假警报。
  3. meta.expect_change 里的档**必须变**；其余档**必须逐字节不变**。

用法：
  python tools/_golden_diff.py tools/_golden_pre_p0.jsonl tools/_golden_post_p0.jsonl
"""
import collections
import json
import sys

# 不参与"变了没有"判定的字段：墙钟/计时派生（重跑有已知波动）
IGNORE = {"seed_ms", "last_call_stats", "generated_at"}


def load(path):
    meta, combos = {}, collections.defaultdict(dict)
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if not line:
            continue
        row = json.loads(line)
        if row.get("t") == "golden_meta":
            meta = row
        elif "combo" in row:
            combos[row["combo"]][row["seed"]] = row
    return meta, combos


def diff_keys(a, b):
    keys = set(a) | set(b)
    out = []
    for k in keys:
        if k in IGNORE:
            continue
        if a.get(k) != b.get(k):
            out.append(k)
    return out


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    pre_meta, pre = load(sys.argv[1])
    post_meta, post = load(sys.argv[2])
    expect_change = set(post_meta.get("expect_change") or pre_meta.get("expect_change") or [])
    print("pre  combos=%d rows=%d" % (len(pre), sum(len(v) for v in pre.values())))
    print("post combos=%d rows=%d" % (len(post), sum(len(v) for v in post.values())))
    print("expect_change=%s" % sorted(expect_change))

    regressions, changed, missing, extra = [], [], [], []
    for combo in sorted(set(pre) | set(post)):
        if combo not in pre:
            extra.append(combo)
            continue
        if combo not in post:
            missing.append(combo)
            continue
        per_seed = []
        for seed in sorted(set(pre[combo]) | set(post[combo])):
            a, b = pre[combo].get(seed), post[combo].get(seed)
            if a is None or b is None:
                per_seed.append((seed, ["<行缺失: pre=%s post=%s>" % (a is not None, b is not None)]))
                continue
            d = diff_keys(a, b)
            if d:
                per_seed.append((seed, d))
        if per_seed:
            changed.append((combo, per_seed))
            if combo not in expect_change:
                regressions.append((combo, per_seed))

    print("\n--- 发生变化的档 ---")
    if not changed:
        print("  （无）")
    for combo, per_seed in changed:
        tag = "期望变化" if combo in expect_change else "!! 意外变化"
        print("  %-16s %s" % (combo, tag))
        for seed, keys in per_seed:
            print("      seed %s: %s" % (seed, ", ".join(keys)))
            a, b = pre[combo][seed], post[combo][seed]
            if "hidden_state" in keys:
                ca = {k: v.get("card") for k, v in (a.get("hidden_state") or {}).items()}
                cb = {k: v.get("card") for k, v in (b.get("hidden_state") or {}).items()}
                print("          hidden_state card: %s -> %s" % (ca, cb))

    print("\n--- 未变化的档（逐字节一致）---")
    unchanged = [c for c in sorted(set(pre) & set(post)) if c not in [x[0] for x in changed]]
    print("  %s" % (unchanged or "（无）"))
    if missing:
        print("\n!! 仅存在于 pre 的档（post 未产出）：%s" % missing)
    if extra:
        print("post 新增的档（pre 无）：%s" % extra)

    print()
    if regressions:
        print("__VERDICT__ REGRESSION —— 既有档意外变化: %s" % [c for c, _ in regressions])
        return 1
    fc = [c for c, _ in changed if c in expect_change]
    print("__VERDICT__ OK —— 既有档逐字节不变；修复域按预期变化: %s" % (fc or "（修复域未变化，需排查）"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
