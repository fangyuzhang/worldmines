# test_hint_solver.gd —— 提示求解器推理链测试（文档 §6.1 / §6.2）
extends GutTest


## 3×3，雷在 (0,0)，中心 value=1，标旗 (0,0)，其余未翻开 → 推 7 个安全格。
func test_classic_hint_safe() -> void:
	var board := Board.new()
	var grid := RectGrid.new()
	grid.setup(3, 3)
	board.grid = grid
	board.total_mines = 1
	board._static_mines = [Vector2i(0, 0)]
	grid.get_cell(Vector2i(0, 0)).is_mine = true
	board._compute_clues()
	grid.get_cell(Vector2i(1, 1)).state = Cell.State.REVEALED  # 中心
	grid.get_cell(Vector2i(0, 0)).state = Cell.State.FLAGGED   # 标旗雷

	var solver := HintSolver.new()
	var steps := solver.hint(board)
	var safe_from_center: Array = []
	for s in steps:
		if s.state == "safe" and s.sources.has(Vector2i(1, 1)):
			safe_from_center.append(s.pos)
	assert_eq(safe_from_center.size(), 7, "中心 value=1 且已标 1 旗，应推出 7 个安全格")
	assert_eq(steps.size(), 7, "总推理步数应为 7")


## 3×3，雷在 (0,0)(0,1)(0,2)，中心 value=3，其余 5 安全格翻开 → 推 3 个雷格。
func test_classic_hint_mine() -> void:
	var board := Board.new()
	var grid := RectGrid.new()
	grid.setup(3, 3)
	board.grid = grid
	board.total_mines = 3
	board._static_mines = [Vector2i(0, 0), Vector2i(0, 1), Vector2i(0, 2)]
	for m in board._static_mines:
		grid.get_cell(m).is_mine = true
	board._compute_clues()
	grid.get_cell(Vector2i(1, 1)).state = Cell.State.REVEALED
	for p in [Vector2i(1, 0), Vector2i(1, 2), Vector2i(2, 0), Vector2i(2, 1), Vector2i(2, 2)]:
		grid.get_cell(p).state = Cell.State.REVEALED

	var solver := HintSolver.new()
	var steps := solver.hint(board)
	var mine_from_center: Array = []
	for s in steps:
		if s.state == "mine" and s.sources.has(Vector2i(1, 1)):
			mine_from_center.append(s.pos)
	assert_eq(mine_from_center.size(), 3, "中心 value=3 且 3 格未翻开，应推出 3 个雷格")


## Clock：中心 value=3 → 方位 1、2 必安全，方位 3 必雷。
func test_clock_hint() -> void:
	var board := Board.new()
	var grid := RectGrid.new()
	grid.setup(3, 3)
	board.grid = grid
	board.total_mines = 1
	board.clue_variant = ClueEngine.Variant.CLOCK
	# 雷在方位 3（右）= (2,1)
	board._static_mines = [Vector2i(2, 1)]
	grid.get_cell(Vector2i(2, 1)).is_mine = true
	board._compute_clues()
	grid.get_cell(Vector2i(1, 1)).state = Cell.State.REVEALED  # 中心，clock value=3

	var solver := HintSolver.new()
	var steps := solver.hint(board)
	var mine_steps: Array = []
	var safe_steps: Array = []
	for s in steps:
		if s.sources.has(Vector2i(1, 1)):
			if s.state == "mine":
				mine_steps.append(s.pos)
			else:
				safe_steps.append(s.pos)
	assert_eq(mine_steps.size(), 1, "clock value=3 应推出 1 个雷格（方位 3）")
	if mine_steps.size() == 1:
		assert_eq(mine_steps[0], Vector2i(2, 1), "方位 3 = 右 = (2,1)")
	assert_eq(safe_steps.size(), 2, "clock value=3 应推出 2 个安全格（方位 1、2）")


## MX 镜像：翻开左半区安全格 → 推镜像格安全。
func test_mx_hint() -> void:
	var board := Board.new()
	var grid := RectGrid.new()
	grid.setup(3, 3)
	board.grid = grid
	board.total_mines = 0
	board.constraint_variant = ConstraintEngine.Variant.MX
	board._compute_clues()
	grid.get_cell(Vector2i(0, 0)).state = Cell.State.REVEALED

	var solver := HintSolver.new()
	var steps := solver.hint(board)
	var found := false
	for s in steps:
		if s.rule == "mx" and s.pos == Vector2i(2, 0) and s.state == "safe":
			found = true
	assert_true(found, "MX 镜像应推出 (2,0) 安全")


## DT 骨牌：骨牌两格恰一雷，翻开一格安全 → 推另一格雷。
func test_dt_hint() -> void:
	var board := Board.new()
	var grid := RectGrid.new()
	grid.setup(2, 2)
	board.grid = grid
	board.total_mines = 1
	board.constraint_variant = ConstraintEngine.Variant.DT
	board.dominoes = [[Vector2i(0, 0), Vector2i(1, 0)], [Vector2i(0, 1), Vector2i(1, 1)]]
	grid.get_cell(Vector2i(0, 0)).state = Cell.State.REVEALED

	var solver := HintSolver.new()
	var steps := solver.hint(board)
	var found := false
	for s in steps:
		if s.rule == "dt" and s.pos == Vector2i(1, 0) and s.state == "mine":
			found = true
	assert_true(found, "DT 骨牌应推出 (1,0) 必雷")


## mod 自定义线索 Def：注册 n4+sum，hint_def 应能按新 Def 推理。
func test_hint_def_supports_custom_def() -> void:
	var board := Board.new()
	var grid := RectGrid.new()
	grid.setup(3, 3)
	board.grid = grid
	board.total_mines = 1
	board.clue_variant = ClueEngine.Variant.N4
	board._static_mines = [Vector2i(1, 0)]
	grid.get_cell(Vector2i(1, 0)).is_mine = true
	board._compute_clues()
	grid.get_cell(Vector2i(1, 1)).state = Cell.State.REVEALED
	grid.get_cell(Vector2i(1, 0)).state = Cell.State.FLAGGED

	var solver := HintSolver.new()
	solver.engine.register_clue_def("my_4n", {"type": "clue", "window": DefEngine.WINDOW_N4, "aggregate": DefEngine.AGG_SUM, "max": 4, "min_clue": 0})
	var steps := solver.hint_def(board, "my_4n")
	var safe_count := 0
	for s in steps:
		if s.state == "safe" and s.sources.has(Vector2i(1, 1)):
			safe_count += 1
	assert_eq(safe_count, 3, "自定义 n4+sum Def 应推出 3 个安全格")
