# test_level_loader.gd —— T4 扫描排序 / T5 全量载入 / T6 异常路径【plan1.1 §10.12.4】
# 事实基线（Step 0 核对）：levels/ 实际 10 关（文档写 13，以代码为准）。
extends GutTest


# T4：list_levels() 非空、按文件名升序、数量 = 实际 10
func test_t4_list_sorted() -> void:
    var levels := LevelLoader.list_levels()
    assert_gt(levels.size(), 0, "关卡列表不应为空")
    assert_eq(levels.size(), 10, "实际预置关数（Step 0 核对结论）")
    var sorted := levels.duplicate()
    sorted.sort()
    assert_eq(levels, sorted, "应按文件名升序")
    for p in levels:
        assert_true(p.begins_with("res://levels/classic_"), "路径前缀: " + p)


# T5：全部关卡 load_level 成功且 board 就绪
func test_t5_all_levels_load() -> void:
    var levels := LevelLoader.list_levels()
    for p in levels:
        var b: Board = LevelLoader.load_level(p)
        assert_not_null(b, "载入失败: " + p)
        if b == null:
            continue
        assert_not_null(b.grid, "grid 未构造: " + p)
        assert_eq(b.grid.size(), Vector2i(5, 5), "5x5 棋盘: " + p)
        assert_eq(b.total_mines, 10, "雷数: " + p)
        assert_eq(b.state, Board.GameState.PLAYING, "初始态 PLAYING: " + p)
        assert_eq(b.get_mine_positions().size(), 10, "雷位数量: " + p)


# T6：不存在路径返回 null（不崩溃）
func test_t6_missing_path_null() -> void:
    var b: Board = LevelLoader.load_level("res://levels/classic_99.json")
    assert_null(b)


# 附加：显示名规则（JSON name 字段 / 文件名回退）
func test_level_display_name() -> void:
    var levels := LevelLoader.list_levels()
    assert_gt(levels.size(), 0)
    var name := LevelLoader.get_level_name(levels[0])
    assert_eq(name, "classic_01", "JSON name 字段 = 文件名")
