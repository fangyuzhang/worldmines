# settings_manager.gd —— 设置持久化（5 项，实时生效）【plan1.1 §10.7.2】
# 设置实时生效：改即存盘即广播；UI 面板控件只调 setter，不直改变量。
extends Node
## autoload 名：SettingsManager

signal settings_changed

const PATH := "user://settings.cfg"

var theme_mode: String = "system"  # "system" | "dark" | "light"
var ripple_enabled: bool = true
var hover_highlight: bool = true
var autosave_enabled: bool = true
var keyboard_enabled: bool = true


func _ready() -> void:
    load_cfg()


## 加载方法名用 load_cfg()，避开保留字歧义（裁决档案 A.1-3）。
func load_cfg() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) != OK:
        return  # 文件不存在 → 按默认值
    theme_mode = _get_str(cfg, "theme_mode", "system")
    ripple_enabled = _get_bool(cfg, "ripple_enabled", true)
    hover_highlight = _get_bool(cfg, "hover_highlight", true)
    autosave_enabled = _get_bool(cfg, "autosave_enabled", true)
    keyboard_enabled = _get_bool(cfg, "keyboard_enabled", true)


func _get_str(cfg: ConfigFile, key: String, fallback: String) -> String:
    var v: Variant = cfg.get_value("game", key, fallback)
    return str(v) if v != null else fallback


func _get_bool(cfg: ConfigFile, key: String, fallback: bool) -> bool:
    var v: Variant = cfg.get_value("game", key, fallback)
    return bool(v) if v is bool else fallback


func save() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("game", "theme_mode", theme_mode)
    cfg.set_value("game", "ripple_enabled", ripple_enabled)
    cfg.set_value("game", "hover_highlight", hover_highlight)
    cfg.set_value("game", "autosave_enabled", autosave_enabled)
    cfg.set_value("game", "keyboard_enabled", keyboard_enabled)
    cfg.save(PATH)


# ============ setter（赋值 → save → 广播；实时生效） ============

func set_theme_mode(v: String) -> void:
    theme_mode = v
    save()
    settings_changed.emit()


func set_ripple_enabled(v: bool) -> void:
    ripple_enabled = v
    save()
    settings_changed.emit()


func set_hover_highlight(v: bool) -> void:
    hover_highlight = v
    save()
    settings_changed.emit()


func set_autosave_enabled(v: bool) -> void:
    autosave_enabled = v
    save()
    settings_changed.emit()


func set_keyboard_enabled(v: bool) -> void:
    keyboard_enabled = v
    save()
    settings_changed.emit()
