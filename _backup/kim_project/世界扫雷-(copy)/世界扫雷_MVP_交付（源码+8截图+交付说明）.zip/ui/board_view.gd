# board_view.gd —— 棋盘渲染 + 拾取 + 键盘 + 涟漪动效 + scale-to-fit【plan1.1 §10.7.6】
# 渲染只 queue_redraw() 交给 Godot 调度，禁手写脏矩形。
# 判负引爆格高亮从 GameSession.exploded_pos 取；终局揭晓绘制雷位允许调
# get_mine_positions()（渲染，非判负逻辑；红线 2 的例外条款）。
# 全部色值经 ThemeManager；无 48px 硬编码（全文件跟随 cell_px）。
extends Control

## cell_px：scale-to-fit 动态格尺寸（§8.4.7 公式；24~48px）
var cell_px: int = 48
## 棋盘绘制原点（恒居中）
var board_origin: Vector2 = Vector2.ZERO
## 鼠标悬停格（-1,-1 = 无）
var hover_pos: Vector2i = Vector2i(-1, -1)

## 涟漪动效队列（§8.4.5）：{pos: Vector2i, t0: float（ msec ）， k: int 级联序号}
var _ripples: Array = []
var _ripple_window_start_ms: int = -1


func _ready() -> void:
    add_to_group("themed")
    ThemeManager.theme_changed.connect(queue_redraw)
    GameSession.session_started.connect(_on_session_started)
    # HUD + GameOver 覆盖层（board_view.tscn 内实例，§10.7.7-③）
    var hud: Control = load("res://ui/hud.tscn").instantiate()
    add_child(hud)
    _game_over = load("res://ui/game_over.tscn").instantiate()
    add_child(_game_over)
    # 双时序兼容：_ready 里手动调一次（恢复路径时 session 先开好、场景后进来）
    _on_session_started()
    get_viewport().connect("size_changed", _layout)
    _layout()


var _game_over: Control


func _on_session_started() -> void:
    _connect_board()
    _ripples.clear()
    _ripple_window_start_ms = -1
    _layout()
    queue_redraw()


## Board 是新实例，每次 start/restart/restore 都重连（§10.11-3）。
func _connect_board() -> void:
    if GameSession.board == null:
        return
    if not GameSession.board.cell_state_changed.is_connected(_on_cell_changed):
        GameSession.board.cell_state_changed.connect(_on_cell_changed)


func _on_cell_changed(pos: Vector2i) -> void:
    # 涟漪触发：任意格子 revealed 状态变更（含连锁翻开）
    if GameSession.board == null:
        return
    var cell := GameSession.board.grid.get_cell(pos)
    if cell != null and cell.state == Cell.State.REVEALED:
        if SettingsManager != null and SettingsManager.ripple_enabled:
            var now_ms := Time.get_ticks_msec()
            if now_ms - _ripple_window_start_ms > 400:
                _ripple_window_start_ms = now_ms
                _ripples.clear()  # 上一波动画窗口关闭，新窗口从 k=0 重新计
            _ripples.append({"pos": pos, "t0": now_ms, "k": _ripples.size()})
    queue_redraw()


func _layout() -> void:
    if GameSession.board == null or GameSession.board.grid == null:
        return
    var size := GameSession.board.grid.size()  # Vector2i(cols, rows)
    var cols: int = size.x
    var rows: int = size.y
    var vp := get_viewport_rect().size
    # §8.4.7：左右边距 48、上 HUD 64 + 上边距 24、下边距 24
    var avail_w: float = vp.x - 48.0
    var avail_h: float = vp.y - 64.0 - 48.0
    cell_px = clampi(floori(min(avail_w / float(cols), avail_h / float(rows))), 24, 48)
    var board_w: float = float(cols) * cell_px
    var board_h: float = float(rows) * cell_px
    board_origin = Vector2((vp.x - board_w) * 0.5, 64.0 + (avail_h - board_h) * 0.5)
    queue_redraw()


func _process(_delta: float) -> void:
    # 涟漪存在期间持续重绘；队列清空即停止（§8.4.5 性能条款）
    if _ripples.is_empty():
        return
    var now_ms := Time.get_ticks_msec()
    _ripples = _ripples.filter(func(rp): return now_ms - rp["t0"] < 400)
    if _ripples.is_empty():
        _ripple_window_start_ms = -1
    queue_redraw()


# ============ 渲染（§8.4.8 逐格绘制，全部色值经 ThemeManager） ============

func _draw() -> void:
    var session := GameSession
    if session.board == null or session.board.grid == null:
        return
    var board: Board = session.board
    var size := board.grid.size()
    var scale := float(cell_px) / 48.0
    var font := ThemeDB.fallback_font
    var endgame: bool = board.state != Board.GameState.PLAYING

    for r in size.y:
        for c in size.x:
            var pos := Vector2i(c, r)
            var cell := board.grid.get_cell(pos)
            var rect := Rect2(board_origin + Vector2(c, r) * cell_px, Vector2(cell_px, cell_px))
            # 涟漪几何（§8.4.5）：中心格缩放弹跳 / 邻格向远离中心平移（直接改绘制矩形，免矩阵）
            var rrect: Rect2 = _ripple_rect_for(pos, rect)
            _draw_cell(pos, cell, rrect, scale, font, endgame)

    # 邻格颜色微闪（§8.4.5：深色 5% 提亮 / 亮色 5% 压暗）
    if not endgame:
        _draw_ripple_flashes()

    # 终局揭晓（非 PLAYING）：全部雷位画雷体 + 引爆格 danger 底
    if endgame:
        _draw_mines_reveal(board, scale)

    # 悬停邻域高亮（§8.4.4；开关 + 终局不响应）
    if not endgame and hover_pos.x >= 0 and SettingsManager != null and SettingsManager.hover_highlight:
        _draw_hover_highlight(hover_pos)

    # 键盘光标（2px 描边框，accent alpha 0.65，与悬停可叠加）
    if not endgame and session.cursor.x >= 0 and SettingsManager != null and SettingsManager.keyboard_enabled:
        var crect := Rect2(board_origin + Vector2(session.cursor.x, session.cursor.y) * cell_px + Vector2(1, 1), Vector2(cell_px - 2, cell_px - 2))
        var col := ThemeManager.accent()
        col.a = 0.65
        draw_rect(crect, col, false, 2.0)


func _draw_cell(pos: Vector2i, cell: Cell, rect: Rect2, scale: float, font: Font, endgame: bool) -> void:
    match cell.state:
        Cell.State.HIDDEN:
            draw_rect(rect, ThemeManager.cell_hidden())
            draw_rect(rect, ThemeManager.grid_line(), false, 1.0)
        Cell.State.FLAGGED:
            _draw_flag(rect, scale)
        Cell.State.QUESTION:
            draw_rect(rect, ThemeManager.cell_hidden())
            draw_rect(rect, ThemeManager.grid_line(), false, 1.0)
            # 居中「?」字号 20（48px 基准），text_secondary
            var fs := int(round(20.0 * scale))
            draw_string(font, rect.position + Vector2(rect.size.x * 0.5 - fs * 0.3, rect.size.y * 0.5 + fs * 0.35), "?", HORIZONTAL_ALIGNMENT_CENTER, rect.size.x, fs, ThemeManager.text_secondary())
        Cell.State.REVEALED:
            draw_rect(rect, ThemeManager.cell_revealed())
            draw_rect(rect, ThemeManager.grid_line(), false, 1.0)
            # 数字 1~8；值为 0 时留空
            var v: Variant = cell.value
            if v is int and v > 0 and v <= 8:
                var fs2 := int(round(26.0 * scale))
                var baseline: float = rect.position.y + rect.size.y * 0.5 + 9.0 * scale
                draw_string(font, rect.position + Vector2(0, baseline), str(v), HORIZONTAL_ALIGNMENT_CENTER, rect.size.x, fs2, ThemeManager.number(v))


## §8.4.8 FLAGGED：HIDDEN 底 + 旗杆 draw_rect + 三角 draw_polygon（48px 基准坐标×scale）
func _draw_flag(rect: Rect2, scale: float) -> void:
    draw_rect(rect, ThemeManager.cell_hidden())
    draw_rect(rect, ThemeManager.grid_line(), false, 1.0)
    var x: float = rect.position.x
    var y: float = rect.position.y
    # 旗杆 Rect2(x+22, y+10, 2, 18)
    var pole := Rect2(x + 22.0 * scale, y + 10.0 * scale, 2.0 * scale, 18.0 * scale)
    draw_rect(pole, ThemeManager.text_secondary())
    # 三角 [(x+24,y+10),(x+24,y+22),(x+37,y+16)]
    var tri := PackedVector2Array([
        Vector2(x + 24.0 * scale, y + 10.0 * scale),
        Vector2(x + 24.0 * scale, y + 22.0 * scale),
        Vector2(x + 37.0 * scale, y + 16.0 * scale),
    ])
    draw_polygon(tri, PackedColorArray([ThemeManager.danger()]))


## 终局揭晓：全部雷位画雷体（圆 + 4 刺线）；引爆格先画 danger 底。
func _draw_mines_reveal(board: Board, scale: float) -> void:
    var exploded: Vector2i = GameSession.exploded_pos
    var body_col := ThemeManager.mine_body()
    for m in board.get_mine_positions():
        var rect := Rect2(board_origin + Vector2(m.x, m.y) * cell_px, Vector2(cell_px, cell_px))
        if m == exploded:
            draw_rect(rect, ThemeManager.danger())
        var center := rect.position + rect.size * 0.5
        draw_circle(center, 11.0 * scale, body_col)
        var spike: float = 15.0 * scale
        draw_line(center + Vector2(0, 6.0 * scale), center + Vector2(0, 6.0 * scale + spike), body_col, 1.5 * scale)
        draw_line(center - Vector2(0, 6.0 * scale), center - Vector2(0, 6.0 * scale + spike), body_col, 1.5 * scale)
        draw_line(center + Vector2(6.0 * scale, 0), center + Vector2(6.0 * scale + spike, 0), body_col, 1.5 * scale)
        draw_line(center - Vector2(6.0 * scale, 0), center - Vector2(6.0 * scale + spike, 0), body_col, 1.5 * scale)


## §8.4.4 悬停邻域高亮：中心格内陷 + 8 邻柔光，不改变格子状态色
func _draw_hover_highlight(center_pos: Vector2i) -> void:
    var board: Board = GameSession.board
    if board == null:
        return
    # 中心格遮罩
    var crect := Rect2(board_origin + Vector2(center_pos.x, center_pos.y) * cell_px, Vector2(cell_px, cell_px))
    draw_rect(crect, ThemeManager.hover_center_overlay())
    # 周围 8 邻（按实际存在的邻格）
    for d in [Vector2i(0, -1), Vector2i(1, -1), Vector2i(1, 0), Vector2i(1, 1), Vector2i(0, 1), Vector2i(-1, 1), Vector2i(-1, 0), Vector2i(-1, -1)]:
        var np: Vector2i = center_pos + d
        if board.grid.in_board(np):
            var nrect := Rect2(board_origin + Vector2(np.x, np.y) * cell_px, Vector2(cell_px, cell_px))
            draw_rect(nrect, ThemeManager.hover_neighbor_overlay())


# ============ 涟漪动效（§8.4.5：150ms 中心弹跳 / 200ms 邻格平移 / 50ms 级联 / ≤400ms） ============

## pos 参与活跃涟漪时返回调整后的绘制矩形（中心缩放 / 邻格位移），否则原样返回。
func _ripple_rect_for(pos: Vector2i, rect: Rect2) -> Rect2:
    if _ripples.is_empty():
        return rect
    var now_ms := Time.get_ticks_msec()
    for rp in _ripples:
        var t: float = (float(now_ms - rp["t0"]) - 50.0 * rp["k"]) / 1000.0
        if t < 0.0:
            continue
        var center: Vector2i = rp["pos"]
        if center == pos:
            # 中心格：缩放 1.0 → 1.15 → 1.0，150ms（矩形绕中心缩放）
            var tc: float = clampf(t / 0.15, 0.0, 1.0)
            var s: float = 1.0 + 0.15 * sin(PI * tc)
            var half := rect.size * 0.5 * s
            var cpos := rect.position + rect.size * 0.5
            return Rect2(cpos - half, half * 2.0)
        elif _is_8_neighbor(pos, center):
            # 邻格：向远离中心方向平移 3px 后回弹，200ms
            var tn: float = clampf(t / 0.2, 0.0, 1.0)
            var amp: float = 3.0 * sin(PI * tn)
            var dir := (Vector2(pos.x, pos.y) - Vector2(center.x, center.y)).normalized()
            if dir.length() < 0.5:
                dir = Vector2.ZERO
            return Rect2(rect.position + dir * amp, rect.size)
    return rect


func _is_8_neighbor(a: Vector2i, b: Vector2i) -> bool:
    var d: Vector2i = (a - b).abs()
    return (d.x <= 1 and d.y <= 1) and not (d.x == 0 and d.y == 0)


## 邻格颜色微闪：深色模式叠加 5% 提亮 / 亮色模式叠加 5% 压暗（§8.4.5）。
func _draw_ripple_flashes() -> void:
    if _ripples.is_empty():
        return
    var now_ms := Time.get_ticks_msec()
    var flash := Color(1, 1, 1, 0.05)
    if ThemeManager.mode == "light":
        flash = Color(0, 0, 0, 0.05)
    for rp in _ripples:
        var t: float = (float(now_ms - rp["t0"]) - 50.0 * rp["k"]) / 1000.0
        if t < 0.0 or t > 0.2:
            continue
        var center: Vector2i = rp["pos"]
        var fade: float = 1.0 - clampf(t / 0.2, 0.0, 1.0)
        var f := flash
        f.a *= fade
        for d in [Vector2i(0, -1), Vector2i(1, -1), Vector2i(1, 0), Vector2i(1, 1), Vector2i(0, 1), Vector2i(-1, 1), Vector2i(-1, 0), Vector2i(-1, -1)]:
            var np: Vector2i = center + d
            if GameSession.board != null and GameSession.board.grid != null and GameSession.board.grid.in_board(np):
                var nrect := Rect2(board_origin + Vector2(np.x, np.y) * cell_px, Vector2(cell_px, cell_px))
                draw_rect(nrect, f)


# ============ 输入（§10.9；一切入口第一行检查 state == PLAYING） ============

func _gui_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        if GameSession.state != GameSession.State.PLAYING:
            return  # 终局冻结（重开/返回是 HUD/GameOver 层的例外按钮）
        var pos := _pick(event.position)
        if pos.x < 0:
            return
        if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
            GameSession.reveal(pos)
            accept_event()
        elif event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
            GameSession.toggle_flag(pos)
            accept_event()
    elif event is InputEventMouseMotion:
        if GameSession.state == GameSession.State.PLAYING:
            var pos := _pick(event.position)
            if pos != hover_pos:
                hover_pos = pos
                queue_redraw()


func _unhandled_key_input(event: InputEvent) -> void:
    if not (event is InputEventKey) or not event.pressed:
        return
    if SettingsManager != null and not SettingsManager.keyboard_enabled:
        return
    if GameSession.state != GameSession.State.PLAYING:
        # R 重开是终局例外（HUD/GameOver 也有按钮；键盘通道同样允许）
        if event.keycode == KEY_R:
            GameSession.restart()
            accept_event()
        return
    var board: Board = GameSession.board
    if board == null or board.grid == null:
        return
    var size := board.grid.size()
    var cur: Vector2i = GameSession.cursor
    var handled := true
    match event.keycode:
        KEY_R:
            GameSession.restart()
        KEY_F:
            GameSession.toggle_flag(cur)
        KEY_SPACE, KEY_ENTER:
            GameSession.reveal(cur)
        KEY_HOME:
            cur.x = 0
        KEY_END:
            cur.x = size.x - 1
        KEY_PAGEUP:
            cur.y = 0
        KEY_PAGEDOWN:
            cur.y = size.y - 1
        KEY_W, KEY_UP:
            cur.y = maxi(cur.y - 1, 0)
        KEY_S, KEY_DOWN:
            cur.y = mini(cur.y + 1, size.y - 1)
        KEY_A, KEY_LEFT:
            if cur.x == 0:
                # 回环：左边界 → 上一行右端
                if cur.y > 0:
                    cur.y -= 1
                    cur.x = size.x - 1
            else:
                cur.x -= 1
        KEY_D, KEY_RIGHT:
            if cur.x == size.x - 1:
                # 回环：右边界 → 下一行左端
                if cur.y < size.y - 1:
                    cur.y += 1
                    cur.x = 0
            else:
                cur.x += 1
        _:
            handled = false
    if handled:
        GameSession.cursor = cur
        queue_redraw()
        accept_event()


func _pick(local_pos: Vector2) -> Vector2i:
    if cell_px <= 0:
        return Vector2i(-1, -1)
    var rel := local_pos - board_origin
    var c := floori(rel.x / float(cell_px))
    var r := floori(rel.y / float(cell_px))
    if GameSession.board == null or GameSession.board.grid == null:
        return Vector2i(-1, -1)
    var size := GameSession.board.grid.size()
    if c < 0 or c >= size.x or r < 0 or r >= size.y:
        return Vector2i(-1, -1)
    return Vector2i(c, r)
