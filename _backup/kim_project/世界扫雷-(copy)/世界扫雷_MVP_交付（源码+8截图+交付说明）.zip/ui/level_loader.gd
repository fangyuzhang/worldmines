# level_loader.gd —— 关卡 JSON → Board 构造【plan1.1 §10.7.3】
# 字段名以实际 JSON 为准（Step 0 第 1 项核对结论）：
#   name / size{rows,cols} / total_mines / mines[{r,c}] / revealed[{r,c,value?|interval?}]
# loader 不做规则层工作（判重、线索计算都在引擎内）。
class_name LevelLoader
extends RefCounted


## 扫描 res://levels/ 下 classic_*.json，按文件名升序返回完整 res:// 路径数组。
static func list_levels() -> Array[String]:
    var out: Array[String] = []
    var dir := DirAccess.open("res://levels")
    if dir == null:
        push_error("levels 目录不存在")
        return out
    var names: Array[String] = []
    dir.list_dir_begin()
    var fname: String = dir.get_next()
    while fname != "":
        if fname.begins_with("classic_") and fname.ends_with(".json"):
            names.append(fname)
        fname = dir.get_next()
    dir.list_dir_end()
    names.sort()  # 字典序 = classic_01 < classic_02 ... < classic_10
    for n in names:
        out.append("res://levels/" + n)
    return out


## 关卡显示名：JSON 有 name 字段用之；否则文件名去后缀（§8.5 关卡条目）。
static func get_level_name(path: String) -> String:
    var d: Variant = _parse_file(path)
    if d is Dictionary and d.has("name") and str(d["name"]) != "":
        return str(d["name"])
    return path.get_file().get_basename()


static func _parse_file(path: String) -> Variant:
    if not FileAccess.file_exists(path):
        return null
    var text := FileAccess.get_file_as_string(path)
    return JSON.parse_string(text)


## 加载关卡 → 返回就绪 Board；任一校验失败 → push_error + null。
static func load_level(path: String) -> Board:
    var parsed: Variant = _parse_file(path)
    if not (parsed is Dictionary):
        push_error("关卡解析失败: " + path)
        return null
    var d: Dictionary = parsed
    return _validate_and_build(d, path)


static func _validate_and_build(d: Dictionary, path: String) -> Board:
    # 结构字段
    if not (d.has("size") and d["size"] is Dictionary):
        push_error("关卡缺 size: " + path)
        return null
    var rows: int = int(d["size"].get("rows", 0))
    var cols: int = int(d["size"].get("cols", 0))
    if rows <= 0 or cols <= 0:
        push_error("关卡尺寸非法: " + path)
        return null
    var total_mines: int = int(d.get("total_mines", -1))
    if total_mines <= 0 or total_mines >= rows * cols:
        push_error("关卡雷数非法: " + path)
        return null

    # 雷位：界内、无重复
    var mines: Array = d.get("mines", [])
    if mines.size() != total_mines:
        push_error("雷位数与 total_mines 不符: " + path)
        return null
    var mine_keys := {}
    for m in mines:
        if not (m is Dictionary) or not m.has("r") or not m.has("c"):
            push_error("雷位缺坐标: " + path)
            return null
        var mr: int = int(m["r"])
        var mc: int = int(m["c"])
        if mr < 0 or mr >= rows or mc < 0 or mc >= cols:
            push_error("雷位越界: " + path)
            return null
        var mkey := Vector2i(mc, mr)
        if mine_keys.has(mkey):
            push_error("雷位重复: " + path)
            return null
        mine_keys[mkey] = true

    # 初始翻开格：界内、非雷、无重复
    var revealed: Array = d.get("revealed", [])
    var rkeys := {}
    for rv in revealed:
        if not (rv is Dictionary) or not rv.has("r") or not rv.has("c"):
            push_error("初始翻开格缺坐标: " + path)
            return null
        var rr: int = int(rv["r"])
        var cc: int = int(rv["c"])
        if rr < 0 or rr >= rows or cc < 0 or cc >= cols:
            push_error("初始翻开格越界: " + path)
            return null
        var rkey := Vector2i(cc, rr)
        if mine_keys.has(rkey):
            push_error("初始翻开格是雷: " + path)
            return null
        if rkeys.has(rkey):
            push_error("初始翻开格重复: " + path)
            return null
        rkeys[rkey] = true

    # 构造（引擎 API = Board.new() + load_level(dict)，Step 0 第 2 项核对结论）
    var board := Board.new()
    board.load_level(d)
    if board.grid == null or board.total_mines != total_mines:
        push_error("引擎构造棋盘失败: " + path)
        return null
    return board
