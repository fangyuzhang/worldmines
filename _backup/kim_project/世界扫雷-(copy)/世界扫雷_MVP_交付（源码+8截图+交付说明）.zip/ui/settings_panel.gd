# settings_panel.gd —— 设置面板（5 项，实时生效 + 持久化）【plan1.1 §10.7.7-⑥】
# 文案 §8.5：标题「设置」，5 项标签 = 主题模式（跟随系统/深色/亮色）、
# 翻开涟漪动效、悬停邻域高亮、自动存档、键盘操作；按钮「返回」。
extends Control

var _theme_opt: OptionButton
var _ripple_chk: CheckButton
var _hover_chk: CheckButton
var _autosave_chk: CheckButton
var _keyboard_chk: CheckButton


func _ready() -> void:
    add_to_group("themed")
    ThemeManager.theme_changed.connect(_on_theme_changed)
    _build_ui()


func _build_ui() -> void:
    var top := HBoxContainer.new()
    top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    top.offset_top = 12
    top.add_theme_constant_override("separation", 16)
    add_child(top)

    var title := Label.new()
    title.text = "设置"
    title.add_theme_font_size_override("font_size", 28)
    top.add_child(title)

    var back := Button.new()
    back.text = "返回"
    back.focus_mode = Control.FOCUS_NONE
    back.pressed.connect(func(): get_tree().change_scene_to_file("res://ui/main_menu.tscn"))
    top.add_child(back)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    center.offset_top = 64
    add_child(center)

    var panel := PanelContainer.new()
    center.add_child(panel)

    var vbox := VBoxContainer.new()
    vbox.add_theme_constant_override("separation", 18)
    panel.add_child(vbox)

    # 行 1：主题模式
    var row1 := HBoxContainer.new()
    row1.add_theme_constant_override("separation", 24)
    _add_label(row1, "主题模式")
    _theme_opt = OptionButton.new()
    _theme_opt.add_item("跟随系统")
    _theme_opt.add_item("深色")
    _theme_opt.add_item("亮色")
    _theme_opt.item_selected.connect(func(idx: int):
        SettingsManager.set_theme_mode(["system", "dark", "light"][idx]))
    row1.add_child(_theme_opt)
    vbox.add_child(row1)

    # 行 2~5：四开关
    _ripple_chk = _add_check_row(vbox, "翻开涟漪动效",
        func(v: bool): SettingsManager.set_ripple_enabled(v))
    _hover_chk = _add_check_row(vbox, "悬停邻域高亮",
        func(v: bool): SettingsManager.set_hover_highlight(v))
    _autosave_chk = _add_check_row(vbox, "自动存档",
        func(v: bool): SettingsManager.set_autosave_enabled(v))
    _keyboard_chk = _add_check_row(vbox, "键盘操作",
        func(v: bool): SettingsManager.set_keyboard_enabled(v))

    # 控件初值 = SettingsManager 当前值
    _theme_opt.selected = ["system", "dark", "light"].find(SettingsManager.theme_mode)
    _ripple_chk.button_pressed = SettingsManager.ripple_enabled
    _hover_chk.button_pressed = SettingsManager.hover_highlight
    _autosave_chk.button_pressed = SettingsManager.autosave_enabled
    _keyboard_chk.button_pressed = SettingsManager.keyboard_enabled

    _apply_theme()


func _add_check_row(parent: Node, label: String, setter: Callable) -> CheckButton:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 24)
    _add_label(row, label)
    var chk := CheckButton.new()
    chk.toggled.connect(setter)
    row.add_child(chk)
    parent.add_child(row)
    return chk


func _add_label(parent: Node, text: String) -> void:
    var lb := Label.new()
    lb.text = text
    lb.custom_minimum_size = Vector2(200, 32)
    lb.add_theme_font_size_override("font_size", 18)
    parent.add_child(lb)


func _apply_theme() -> void:
    for n in get_children():
        if n is HBoxContainer:
            for c in n.get_children():
                if c is Label:
                    c.add_theme_color_override("font_color", ThemeManager.text())
                elif c is Button:
                    _style_button(c)
        elif n is CenterContainer:
            for p in n.get_children():
                if p is PanelContainer:
                    var sb := StyleBoxFlat.new()
                    sb.bg_color = ThemeManager.card()
                    sb.set_corner_radius_all(10)
                    p.add_theme_stylebox_override("panel", sb)
                    for v in p.get_children():
                        if v is VBoxContainer:
                            for row in v.get_children():
                                for c in row.get_children():
                                    if c is Label:
                                        c.add_theme_color_override("font_color", ThemeManager.text())
                                    elif c is Button:
                                        _style_button(c)
    queue_redraw()


func _style_button(btn: Button) -> void:
    var sb := StyleBoxFlat.new()
    sb.bg_color = ThemeManager.card()
    sb.set_corner_radius_all(6)
    btn.add_theme_stylebox_override("normal", sb)
    btn.add_theme_color_override("font_color", ThemeManager.text())
    var sbh := sb.duplicate()
    sbh.bg_color = ThemeManager.accent()
    btn.add_theme_stylebox_override("hover", sbh)


func _on_theme_changed() -> void:
    _apply_theme()
