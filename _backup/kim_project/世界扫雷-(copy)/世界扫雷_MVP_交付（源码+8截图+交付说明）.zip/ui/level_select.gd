# level_select.gd —— 关卡选择（动态列表）【plan1.1 §10.7.7-②】
# 文案 §8.5：标题「选择关卡」，按钮「返回」，关卡条目 = JSON name / 文件名。
# start_level 失败不切场景 + toast「关卡加载失败」；空列表显示「未找到可用关卡」。
extends Control


func _ready() -> void:
    add_to_group("themed")
    ThemeManager.theme_changed.connect(_on_theme_changed)
    _build_ui()


func _build_ui() -> void:
    # 顶栏：标题 + 返回
    var top := HBoxContainer.new()
    top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    top.offset_top = 12
    top.add_theme_constant_override("separation", 16)
    add_child(top)

    var title := Label.new()
    title.text = "选择关卡"
    title.add_theme_font_size_override("font_size", 28)
    top.add_child(title)

    var back := Button.new()
    back.text = "返回"
    back.focus_mode = Control.FOCUS_NONE
    back.pressed.connect(func(): get_tree().change_scene_to_file("res://ui/main_menu.tscn"))
    top.add_child(back)

    # 滚动列表
    var scroll := ScrollContainer.new()
    scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    scroll.offset_top = 64
    scroll.offset_bottom = -16
    scroll.offset_left = 320
    scroll.offset_right = -320
    add_child(scroll)

    var vbox := VBoxContainer.new()
    vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(vbox)

    # 动态填充关卡（10 关 = Step 0 核对事实；代码动态列出）
    var levels := LevelLoader.list_levels()
    if levels.is_empty():
        var empty_lb := Label.new()
        empty_lb.text = "未找到可用关卡"
        empty_lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        vbox.add_child(empty_lb)
        push_error("关卡列表为空（LevelLoader.list_levels 为空）")
    for path in levels:
        var btn := Button.new()
        btn.text = "第 %d 关 · %s" % [levels.find(path) + 1, LevelLoader.get_level_name(path)]
        btn.focus_mode = Control.FOCUS_NONE
        btn.custom_minimum_size = Vector2(360, 48)
        btn.pressed.connect(func():
            if GameSession.start_level(path):
                get_tree().change_scene_to_file("res://ui/board_view.tscn")
            else:
                _toast("关卡加载失败"))
        vbox.add_child(btn)

    _apply_theme()


func _toast(msg: String) -> void:
    var lb := Label.new()
    lb.text = msg
    lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    lb.add_theme_font_size_override("font_size", 18)
    lb.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    lb.position = Vector2(0, 8)
    lb.custom_minimum_size = Vector2(0, 32)
    add_child(lb)
    var timer := Timer.new()
    timer.wait_time = 2.0
    timer.one_shot = true
    timer.timeout.connect(lb.queue_free)
    timer.timeout.connect(timer.queue_free)
    add_child(timer)
    timer.start()


func _apply_theme() -> void:
    for n in get_children():
        if n is HBoxContainer:
            for c in n.get_children():
                if c is Label:
                    c.add_theme_color_override("font_color", ThemeManager.text())
                elif c is Button:
                    _style_button(c)
        elif n is ScrollContainer:
            for sc in n.get_children():
                if sc is VBoxContainer:
                    for c in sc.get_children():
                        if c is Button:
                            _style_button(c)
                        elif c is Label:
                            c.add_theme_color_override("font_color", ThemeManager.text_secondary())
    queue_redraw()


func _style_button(btn: Button) -> void:
    var sb := StyleBoxFlat.new()
    sb.bg_color = ThemeManager.card()
    sb.set_corner_radius_all(6)
    btn.add_theme_stylebox_override("normal", sb)
    btn.add_theme_color_override("font_color", ThemeManager.text())
    var sbh := sb.duplicate()
    sbh.bg_color = ThemeManager.accent()
    btn.add_theme_stylebox_override("hover", sbh)


func _on_theme_changed() -> void:
    _apply_theme()
