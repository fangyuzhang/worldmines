# puzzle_generator.gd —— 关卡生成器（文档 §4.4 全流程）
# 确定性布雷（仅种子 RNG）→ 单点开局 → 遮蔽 → 唯一解验证 → 纯逻辑可解验证。
# 全局约束型用专用布雷策略（镜像/骨牌/象限/端点/四色/行锁），PF 用随机+过滤。
class_name PuzzleGenerator
extends RefCounted

const MAX_ATTEMPTS := 500
const MAX_MINES_RATIO := 0.4  # 默认雷密度上限

var _rng := RandomNumberGenerator.new()


## 生成一个关卡（返回 level dict，可直接 board.load_level）。
## variant_code: VariantRegistry 的变体码；size: [cols, rows]；mines: 雷数（≤0 则自动取 30%）。
## seed: 确定性种子。
func generate(variant_code: String, size: Vector2i, mine_count: int, seed: int) -> Dictionary:
	var def: Dictionary = VariantRegistry.definitions()[variant_code]
	var clue: int = def["clue"]
	var constraint: int = def["constraint"]
	var cols := size.x
	var rows := size.y
	var n := cols * rows
	if mine_count <= 0:
		mine_count = int(n * 0.3)
	mine_count = clampi(mine_count, 1, n - 1)
	# 4C 四向守恒要求总雷数为偶数，向下调整
	if constraint == ConstraintEngine.Variant.FOUR_COLOR:
		mine_count -= mine_count % 2
		mine_count = maxi(mine_count, 2)

	_rng.seed = seed
	_dominoes = []

	# 单点开局要求 minimal_clue_value >= 0；FR 等无弱信息值的变体不支持单点开局（文档 §4.2）
	if int(def.get("min_clue", 0)) < 0:
		return {}

	# 总时间熔断（文档 §10.1 生成器预算 ≤15s；计时非随机熵源）
	var deadline: int = Time.get_ticks_msec() + 15_000

	for attempt in MAX_ATTEMPTS:
		if Time.get_ticks_msec() > deadline:
			push_warning("PuzzleGenerator: 生成超时 %s" % variant_code)
			return {}
		# 1. 确定性布雷（满足全局约束）
		var mines := _place_mines(constraint, cols, rows, mine_count)
		if mines.is_empty():
			continue

		var board := Board.new()
		board.set_variant(clue, constraint, _dominoes)
		board.total_mines = mines.size()
		board._static_mines = mines
		var grid := RectGrid.new()
		grid.setup(rows, cols)
		board.grid = grid
		for m in mines:
			grid.get_cell(m).is_mine = true
		board._compute_clues()

		# 2. 单点开局：选线索值 == minimal_clue_value 的安全格
		var opening := _pick_opening(board, def)
		if opening == Vector2i(-1, -1):
			continue

		# 3. 翻开开局格（连锁扩散）
		board.reveal(opening)

		# 4. 唯一解 + 纯逻辑可解验证（用初始视角约束集 S）
		var check := VariantConstraint.new(clue, constraint, _dominoes)
		var check_callable := Callable(check, "check")
		var player := SolverPerfectPlayer.new()
		var result := player.solve(board, check_callable)
		if not result[0]:
			continue  # 不可纯逻辑解或断链，回滚重试

		# 5. 唯一解校验：初始视角约束集 S 的解数 == 1
		var revealed := player._collect_revealed(board)
		var oracle := BruteForceOracle.new()
		var verdict := oracle.query_variant(Vector2i(cols, rows), revealed, mines.size(), check_callable)
		# verdict 非空即至少一解；唯一解由完美玩家成功 + 单点开局隐含（见文档 §3.4 唯一性单查即充分）

		return _build_level(variant_code, rows, cols, mines, board, opening)

	return {}  # 重试预算耗尽


## 生成全局约束型关卡（带约束布雷 + 骨牌数据）。
func generate_constrained(variant_code: String, size: Vector2i, mine_count: int, seed: int) -> Dictionary:
	_dominoes = []
	return generate(variant_code, size, mine_count, seed)


## 构造式生成（第三篇 P0）：逆向删线索 + 唯一解保持 + 纯逻辑可解验证。
## 从全翻开出发，逐步关闭格子（保持唯一解），得到最少线索的谜题，再验证可解。
## 相比「随机布雷+验证+重试」：唯一解是构造保证的，不需碰运气；但仍需可解验证（唯一解 ≠ 纯逻辑可解）。
func generate_constructive(variant_code: String, size: Vector2i, mine_count: int, seed: int) -> Dictionary:
	var def: Dictionary = VariantRegistry.definitions()[variant_code]
	var clue: int = def["clue"]
	var constraint: int = def["constraint"]
	var cols := size.x
	var rows := size.y
	var n := cols * rows
	if mine_count <= 0:
		mine_count = int(n * 0.3)
	mine_count = clampi(mine_count, 1, n - 1)
	if constraint == ConstraintEngine.Variant.FOUR_COLOR:
		mine_count -= mine_count % 2
		mine_count = maxi(mine_count, 2)
	# FR 等无弱信息值的变体不支持（同 generate）
	if int(def.get("min_clue", 0)) < 0:
		return {}

	_rng.seed = seed
	_dominoes = []

	var deadline: int = Time.get_ticks_msec() + 15_000

	for attempt in 50:
		if Time.get_ticks_msec() > deadline:
			push_warning("PuzzleGenerator: 构造式生成超时 %s" % variant_code)
			return {}

		# 1. 确定性布雷（满足全局约束）
		var mines := _place_mines(constraint, cols, rows, mine_count)
		if mines.is_empty():
			continue

		# 2. 建棋盘 + 计算线索
		var board := _make_board(clue, constraint, mines, cols, rows)

		# 3. 逆向删线索（保持唯一解）
		var givens := _prune_clues(board, clue, constraint, mines, cols, rows, deadline)
		if givens.is_empty():
			continue

		# 4. 纯逻辑可解验证（settle：翻开 givens 触发连锁扩散）
		var play_board := _make_board(clue, constraint, mines, cols, rows)
		for g in givens:
			play_board.reveal(g)
		var check := VariantConstraint.new(clue, constraint, _dominoes)
		var player := SolverPerfectPlayer.new()
		var result := player.solve(play_board, Callable(check, "check"))
		if not result[0]:
			continue

		# 5. 输出
		return _build_level_from_givens(variant_code, rows, cols, mines, givens)

	return {}


## 建棋盘 + 布雷 + 计算线索。
func _make_board(clue: int, constraint: int, mines: Array[Vector2i], cols: int, rows: int) -> Board:
	var board := Board.new()
	board.set_variant(clue, constraint, _dominoes)
	board.total_mines = mines.size()
	board._static_mines = mines
	var grid := RectGrid.new()
	grid.setup(rows, cols)
	board.grid = grid
	for m in mines:
		grid.get_cell(m).is_mine = true
	board._compute_clues()
	return board


## 逆向删线索：从全翻开出发，逐步关闭格子（保持唯一解）。返回最终 givens。
func _prune_clues(board: Board, clue: int, constraint: int, mines: Array[Vector2i], cols: int, rows: int, deadline: int) -> Array[Vector2i]:
	var gsize := board.grid.size()
	# 初始翻开集合 = 所有非雷格
	var revealed_set := {}
	var non_mine: Array[Vector2i] = []
	for r in gsize.y:
		for c in gsize.x:
			var pos := Vector2i(c, r)
			if not board.is_mine(pos):
				revealed_set[pos] = true
				non_mine.append(pos)

	var check := VariantConstraint.new(clue, constraint, _dominoes)
	var check_callable := Callable(check, "check")
	var total := mines.size()
	var oracle := BruteForceOracle.new()

	# 启发式：优先删约束最弱的格（线索值接近值域中心），提升可解命中率、减少重试
	var center := float(ClueEngine.value_upper_bound(clue, Vector2i(cols, rows))) * 0.5
	var _b := board
	non_mine.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		var va: Variant = _b.grid.get_cell(a).value
		var vb: Variant = _b.grid.get_cell(b).value
		var da: float = absf(float(va) - center) if va is int else center
		var db: float = absf(float(vb) - center) if vb is int else center
		if da != db:
			return da < db
		return a.y < b.y or (a.y == b.y and a.x < b.x)
	)

	for pos in non_mine:
		if Time.get_ticks_msec() > deadline:
			break
		revealed_set.erase(pos)  # 尝试关闭
		var constraints := _collect_constraints(board, revealed_set)
		# 经典线索走内化剪枝计数（快一个数量级）；其余线索型走变体回溯
		var cnt: int
		if clue == ClueEngine.Variant.CLASSIC:
			cnt = oracle.count_solutions_classic(Vector2i(cols, rows), constraints, total, constraint, _dominoes, [], 2)
		else:
			cnt = oracle.count_solutions_variant(Vector2i(cols, rows), constraints, total, check_callable, [], 2)
		if cnt != 1:
			revealed_set[pos] = true  # 多解/无解/超限，撤销

	var givens: Array[Vector2i] = []
	for pos in revealed_set:
		givens.append(pos)
	return givens


## 从翻开集合构造玩家视角约束（绕过 cell.state，直接用 cell.value）。
func _collect_constraints(board: Board, revealed_set: Dictionary) -> Dictionary:
	var constraints := {}
	for pos in revealed_set:
		var cell := board.grid.get_cell(pos)
		if cell.value is Array:
			constraints[pos] = {"type": "equality_pair", "a": cell.value[0], "b": cell.value[1]}
		else:
			constraints[pos] = {"type": "equality", "value": cell.value}
	return constraints


## 从 givens 构造 level dict（revealed 只存坐标，线索值由 load 时重算）。
func _build_level_from_givens(variant_code: String, rows: int, cols: int, mines: Array[Vector2i], givens: Array[Vector2i]) -> Dictionary:
	var revealed: Array = []
	for g in givens:
		revealed.append({"r": g.y, "c": g.x})
	var mines_arr: Array = []
	for m in mines:
		mines_arr.append({"r": m.y, "c": m.x})
	return {
		"variant": variant_code,
		"size": {"rows": rows, "cols": cols},
		"total_mines": mines.size(),
		"mines": mines_arr,
		"revealed": revealed,
	}


## Fisher-Yates 原地打乱 Array[Vector2i]。
func _rng_shuffle_vec2i(arr: Array[Vector2i]) -> void:
	for i in range(arr.size() - 1, 0, -1):
		var j := _rng.randi_range(0, i)
		var t := arr[i]
		arr[i] = arr[j]
		arr[j] = t


# ============ 布雷策略 ============

var _dominoes: Array = []


func _place_mines(constraint: int, cols: int, rows: int, mine_count: int) -> Array[Vector2i]:
	match constraint:
		ConstraintEngine.Variant.MX:
			return _place_mx(cols, rows, mine_count)
		ConstraintEngine.Variant.QD:
			return _place_qd(cols, rows, mine_count)
		ConstraintEngine.Variant.DT:
			return _place_dt(cols, rows, mine_count)
		ConstraintEngine.Variant.EP:
			return _place_ep(cols, rows, mine_count)
		ConstraintEngine.Variant.FOUR_COLOR:
			return _place_4c(cols, rows, mine_count)
		ConstraintEngine.Variant.RL:
			return _place_rl(cols, rows, mine_count)
		ConstraintEngine.Variant.PF:
			return _place_pf(cols, rows, mine_count)
		_:
			return _place_random(cols, rows, mine_count)


## 经典/无约束：随机布雷。
func _place_random(cols: int, rows: int, mine_count: int) -> Array[Vector2i]:
	var cells: Array[Vector2i] = []
	for r in rows:
		for c in cols:
			cells.append(Vector2i(c, r))
	return _sample(cells, mine_count)


## G1 镜像：反推左半区(不含轴) k 个 + 轴列 j 个（2k+j = mine_count），确定性放置。
func _place_mx(cols: int, rows: int, mine_count: int) -> Array[Vector2i]:
	var has_axis := (cols % 2 == 1)
	var left_cols := cols / 2  # 不含轴列的左半区列数（偶数=cols/2，奇数=(cols-1)/2）
	var left_cells: Array[Vector2i] = []
	var axis_cells: Array[Vector2i] = []
	for r in rows:
		for c in left_cols:
			left_cells.append(Vector2i(c, r))
		if has_axis:
			axis_cells.append(Vector2i(cols / 2, r))
	# 收集所有合法 (k, j)：2k + j = mine_count
	var options: Array = []
	var max_j: int = axis_cells.size() if has_axis else 0
	for j in range(max_j + 1):
		if j > mine_count:
			break
		var rem := mine_count - j
		if rem % 2 != 0:
			continue
		var k := rem / 2
		if k > left_cells.size():
			continue
		options.append([k, j])
	if options.is_empty():
		return []
	var pick: Array = options[_rng.randi_range(0, options.size() - 1)]
	var k: int = pick[0]
	var j: int = pick[1]
	var mines := {}
	for m in _sample(left_cells, k):
		mines[m] = true
		mines[Vector2i(cols - 1 - m.x, m.y)] = true
	for m in _sample(axis_cells, j):
		mines[m] = true
	return _dict_keys_vec2i(mines)


## G4 四象：四象限各 k 雷，中央行/列随机。先建象限划分，再反推 k。
func _place_qd(cols: int, rows: int, mine_count: int) -> Array[Vector2i]:
	var mid_r := rows / 2
	var mid_c := cols / 2
	var cross: Array[Vector2i] = []
	var q_ul: Array[Vector2i] = []  # 左上
	var q_ur: Array[Vector2i] = []  # 右上
	var q_ll: Array[Vector2i] = []  # 左下
	var q_lr: Array[Vector2i] = []  # 右下
	for r in rows:
		for c in cols:
			var pos := Vector2i(c, r)
			if r == mid_r or c == mid_c:
				cross.append(pos)
			elif r < mid_r:
				if c < mid_c:
					q_ul.append(pos)
				else:
					q_ur.append(pos)
			else:
				if c < mid_c:
					q_ll.append(pos)
				else:
					q_lr.append(pos)
	# 每象限可容纳的雷数上限 = 最小象限格数（偶数尺寸四象限不对称，必须取最小）
	var q_max: int = q_ul.size()
	q_max = mini(q_max, q_ur.size())
	q_max = mini(q_max, q_ll.size())
	q_max = mini(q_max, q_lr.size())
	for k in range(q_max + 1):
		if 4 * k > mine_count:
			break
		var remaining := mine_count - 4 * k
		if remaining <= cross.size():
			var mines := {}
			for m in _sample(q_ul, k):
				mines[m] = true
			for m in _sample(q_ur, k):
				mines[m] = true
			for m in _sample(q_ll, k):
				mines[m] = true
			for m in _sample(q_lr, k):
				mines[m] = true
			for m in _sample(cross, remaining):
				mines[m] = true
			return _dict_keys_vec2i(mines)
	return []


## G5 骨牌：生成骨牌划分，每骨牌恰 1 雷。
func _place_dt(cols: int, rows: int, mine_count: int) -> Array[Vector2i]:
	# 偶数尺寸无缝覆盖；奇数尺寸留 1 自由格
	var cells: Array[Vector2i] = []
	for r in rows:
		for c in cols:
			cells.append(Vector2i(c, r))
	# 贪心骨牌划分（水平优先）
	var used := {}
	var dominoes: Array = []
	for r in rows:
		for c in cols:
			var a := Vector2i(c, r)
			if used.has(a):
				continue
			var b := Vector2i(c + 1, r)
			if c + 1 < cols and not used.has(b):
				used[a] = true
				used[b] = true
				dominoes.append([a, b])
			else:
				var bv := Vector2i(c, r + 1)
				if r + 1 < rows and not used.has(bv):
					used[a] = true
					used[bv] = true
					dominoes.append([a, bv])
				else:
					used[a] = true  # 自由格
	if dominoes.size() < mine_count:
		return []
	_dominoes = _sample_dominoes(dominoes, mine_count)
	var mines: Array[Vector2i] = []
	for d in _dominoes:
		# 每骨牌随机选 1 格布雷
		mines.append(d[_rng.randi_range(0, 1)])
	return mines


func _sample_dominoes(dominoes: Array, k: int) -> Array:
	var idx: Array[int] = []
	for i in dominoes.size():
		idx.append(i)
	# Fisher-Yates
	for i in range(idx.size() - 1, 0, -1):
		var j := _rng.randi_range(0, i)
		var t := idx[i]
		idx[i] = idx[j]
		idx[j] = t
	var out: Array = []
	for i in k:
		out.append(dominoes[idx[i]])
	return out


## G6 端点平衡：最左/最右列各 k 雷，中间随机。
func _place_ep(cols: int, rows: int, mine_count: int) -> Array[Vector2i]:
	if cols <= 1:
		return []
	for k in range(rows + 1):
		if 2 * k > mine_count:
			break
		var middle: Array[Vector2i] = []
		for r in rows:
			for c in range(1, cols - 1):
				middle.append(Vector2i(c, r))
		var remaining := mine_count - 2 * k
		if remaining <= middle.size():
			var mines := {}
			for r in _sample(_col_cells(0, rows), k):
				mines[r] = true
			for r in _sample(_col_cells(cols - 1, rows), k):
				mines[r] = true
			for m in _sample(middle, remaining):
				mines[m] = true
			return _dict_keys_vec2i(mines)
	return []


## G7 四色：黑白各 k 雷。
func _place_4c(cols: int, rows: int, mine_count: int) -> Array[Vector2i]:
	if mine_count % 2 != 0:
		return []  # 总雷数必须为偶数
	var k := mine_count / 2
	var black: Array[Vector2i] = []
	var white: Array[Vector2i] = []
	for r in rows:
		for c in cols:
			if (c + r) % 2 == 0:
				black.append(Vector2i(c, r))
			else:
				white.append(Vector2i(c, r))
	if black.size() < k or white.size() < k:
		return []
	var mines := {}
	for m in _sample(black, k):
		mines[m] = true
	for m in _sample(white, k):
		mines[m] = true
	return _dict_keys_vec2i(mines)


## G2 相邻行锁：DFS 构造行雷数序列（每步 ±1，总和 = mine_count），再逐行布雷。
func _place_rl(cols: int, rows: int, mine_count: int) -> Array[Vector2i]:
	for _try in 50:
		var seq: Array[int] = []
		seq.resize(rows)
		if _rl_dfs(seq, 0, cols, rows, mine_count, 0):
			var mines := {}
			for r in rows:
				var row_cells: Array[Vector2i] = []
				for c in cols:
					row_cells.append(Vector2i(c, r))
				for m in _sample(row_cells, seq[r]):
					mines[m] = true
			return _dict_keys_vec2i(mines)
	return []


## DFS 构造行序列（带上下界剪枝）。seq[r] 待填，cur_sum 为前 r 行总和。
func _rl_dfs(seq: Array[int], r: int, cols: int, rows: int, target: int, cur_sum: int) -> bool:
	if r == rows:
		return cur_sum == target
	var rem_rows := rows - r - 1
	var cands: Array[int] = []
	if r == 0:
		for v in range(cols + 1):
			cands.append(v)
	else:
		for d: int in [-1, 1]:
			var v: int = seq[r - 1] + d
			if v >= 0 and v <= cols:
				cands.append(v)
	# 随机打乱候选，增加多样性
	for i in range(cands.size() - 1, 0, -1):
		var jj := _rng.randi_range(0, i)
		var t := cands[i]
		cands[i] = cands[jj]
		cands[jj] = t
	for v in cands:
		var rem_need: int = target - cur_sum - v
		if rem_need < 0 or rem_need > rem_rows * cols:
			continue
		seq[r] = v
		if _rl_dfs(seq, r + 1, cols, rows, target, cur_sum + v):
			return true
	return false


## G3 局部禁形：随机布雷 + 2×2 过滤。
func _place_pf(cols: int, rows: int, mine_count: int) -> Array[Vector2i]:
	for _attempt in 300:
		var mines := _place_random(cols, rows, mine_count)
		var ms := {}
		for m in mines:
			ms[m] = true
		if ConstraintEngine.check(ConstraintEngine.Variant.PF, ms, Vector2i(cols, rows)):
			return mines
	return []


# ============ 工具 ============

## Dictionary(Vector2i -> bool) 转 Array[Vector2i]（Dictionary.keys() 返回无类型 Array，需显式转换）。
func _dict_keys_vec2i(d: Dictionary) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	for k in d:
		out.append(k)
	return out


func _col_cells(col: int, rows: int) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	for r in rows:
		out.append(Vector2i(col, r))
	return out


## Fisher-Yates 采样 k 个（不重复）。
func _sample(cells: Array[Vector2i], k: int) -> Array[Vector2i]:
	if k <= 0:
		return []
	if k > cells.size():
		return []
	var idx: Array[int] = []
	for i in cells.size():
		idx.append(i)
	for i in range(idx.size() - 1, 0, -1):
		var j := _rng.randi_range(0, i)
		var t := idx[i]
		idx[i] = idx[j]
		idx[j] = t
	var out: Array[Vector2i] = []
	for i in k:
		out.append(cells[idx[i]])
	return out


## 选单点开局：线索值 == minimal_clue_value 的安全格，优先扩散面积最大者。
## 扩散面积越大 → 初始线索越充分 → 纯逻辑可解命中率越高（第三篇 P0 优化）。
func _pick_opening(board: Board, def: Dictionary) -> Vector2i:
	var min_clue: Variant = def.get("min_clue", 0)
	var gsize := board.grid.size()
	var candidates: Array[Vector2i] = []
	for r in gsize.y:
		for c in gsize.x:
			var pos := Vector2i(c, r)
			var cell := board.grid.get_cell(pos)
			if cell.is_mine:
				continue
			if cell.value == min_clue:
				candidates.append(pos)
	if candidates.is_empty():
		return Vector2i(-1, -1)
	# 选择连锁扩散面积最大的候选（相等则随机）
	var best: Array[Vector2i] = []
	var best_area := -1
	for pos in candidates:
		var area := _reveal_area(board, pos)
		if area > best_area:
			best_area = area
			best = [pos]
		elif area == best_area:
			best.append(pos)
	return best[_rng.randi_range(0, best.size() - 1)]


## 计算翻开 pos 后的连锁扩散格数（含 pos；0 格继续扩散，边界数字格计入）。
func _reveal_area(board: Board, pos: Vector2i) -> int:
	var stack: Array[Vector2i] = [pos]
	var visited := {}
	var count := 0
	while not stack.is_empty():
		var p: Vector2i = stack.pop_back()
		if visited.has(p):
			continue
		visited[p] = true
		var cell := board.grid.get_cell(p)
		if cell.is_mine:
			continue
		count += 1
		if cell.is_zero_clue():
			for nb in board.grid.get_neighbors(p):
				if not visited.has(nb):
					stack.append(nb)
	return count


func _build_level(variant_code: String, rows: int, cols: int, mines: Array[Vector2i], board: Board, opening: Vector2i) -> Dictionary:
	var revealed: Array = []
	# 收集 settle 后所有已翻开格（含连锁扩散）
	var gsize := board.grid.size()
	for r in gsize.y:
		for c in gsize.x:
			var pos := Vector2i(c, r)
			var cell := board.grid.get_cell(pos)
			if cell.state == Cell.State.REVEALED:
				var val: Variant = cell.value
				revealed.append({"r": r, "c": c, "value": val})
	var mines_arr: Array = []
	for m in mines:
		mines_arr.append({"r": m.y, "c": m.x})
	return {
		"variant": variant_code,
		"size": {"rows": rows, "cols": cols},
		"total_mines": mines.size(),
		"mines": mines_arr,
		"revealed": revealed,
	}
