# cell.gd —— 格子数据（文档 §4.2）
# { state, value, hidden_interval, comps }
# state ∈ { HIDDEN, REVEALED, FLAGGED, QUESTION }
# value 为 Variant：int（单值线索）/ Array[A,B]（HV 双值）/ String "inf"（FR 无雷）。
class_name Cell
extends RefCounted

enum State { HIDDEN, REVEALED, FLAGGED, QUESTION }

var state: int = State.HIDDEN
var is_mine: bool = false
var value: Variant = 0           # 引擎视角真实线索值（int / Array / "inf"）
var hidden_interval: Vector2i = Vector2i(-1, -1)  # ? 格遮蔽区间 [lo, hi]；(-1,-1) = 非 ? 格
var comps: Array[CellComp] = []   # 组件列表，P0 为空，P4 沙箱实装


## 是否「? 线索格」：已翻开 + 带 interval 遮蔽。
func is_hidden_clue() -> bool:
	return state == State.REVEALED and hidden_interval.x >= 0


## 玩家视角约束（文档 §3.3 双视角）。求解/计数/提示的唯一入口。
## 返回：
##   { "type": "equality", "value": v }        单值线索（含 FR 的 "inf"）
##   { "type": "equality_pair", "a": A, "b": B } HV 双值线索
##   { "type": "interval", "lo": a, "hi": b }  ? 遮蔽格
##   { "type": "none" }                        未翻开
func get_player_constraint() -> Dictionary:
	if state != State.REVEALED:
		return { "type": "none" }
	if is_hidden_clue():
		return { "type": "interval", "lo": hidden_interval.x, "hi": hidden_interval.y }
	if value is Array:
		return { "type": "equality_pair", "a": value[0], "b": value[1] }
	return { "type": "equality", "value": value }


## 线索值是否为"邻域无雷"（用于连锁扩散判定）。双值/射线不参与自动扩散。
func is_zero_clue() -> bool:
	return value is int and value == 0
