# board.gd —— 棋盘核心（文档 §3.2/§3.3/§3.4/§4.2）【人工锁死】
# 双视角隔离：求解器/提示器只准通过 get_player_constraint(pos) 获取玩家视角约束。
# 判负唯一入口：is_mine(pos)。get_mine_positions() 注释锁死 P4 语义：返回 _static ∪ _dynamic。
class_name Board
extends RefCounted

enum GameState { PLAYING, WON, LOST }

signal game_won
signal game_lost
## 〔plan1.1 §10.2.3〕唯一许可的新增信号：单格状态变更（渲染/动效监听）。不得触碰判负/判胜逻辑。
signal cell_state_changed(pos: Vector2i)

var grid: RectGrid = null
var total_mines: int = 0
var state: int = GameState.PLAYING

# 变体配置（默认经典）。clue 见 ClueEngine.Variant，constraint 见 ConstraintEngine.Variant（-1 = 无）。
var clue_variant: int = ClueEngine.Variant.CLASSIC
var constraint_variant: int = -1
var dominoes: Array = []  # G5 骨牌划分数据（Array[Array[Vector2i]]），仅 DT 用

# 静态雷位（P0 唯一来源）。P4 扩展为 _static ∪ _dynamic，但本字段不更名。
var _static_mines: Array[Vector2i] = []


## 从预置关卡 JSON 构造棋盘。
## 关卡格式（用户版）：
##   { "size": {"rows":R, "cols":C}, "total_mines":N,
##     "mines": [{"r":r,"c":c}, ...],
##     "revealed": [{"r":r,"c":c,"value":v} 或 {"r":r,"c":c,"interval":[lo,hi]}, ...],
##     "known_answers": {"r,c": value} }
## 内部坐标 Vector2i(col, row) = Vector2i(c, r)。
func load_level(level: Dictionary) -> void:
        state = GameState.PLAYING
        total_mines = level.get("total_mines", 0)
        _static_mines.clear()

        var sz: Dictionary = level.get("size", {})
        var rows: int = sz.get("rows", 0)
        var cols: int = sz.get("cols", 0)
        grid = RectGrid.new()
        grid.setup(rows, cols)

        for m in level.get("mines", []):
                var pos := Vector2i(m["c"], m["r"])
                _static_mines.append(pos)
                grid.get_cell(pos).is_mine = true

        _compute_clues()

        # revealed 条目：带 interval 的是 ? 格（遮蔽），带 value 的是普通数字格。
        for r in level.get("revealed", []):
                var pos := Vector2i(r["c"], r["r"])
                if r.has("interval"):
                        var iv: Array = r["interval"]
                        var cell := grid.get_cell(pos)
                        cell.hidden_interval = Vector2i(iv[0], iv[1])
                reveal(pos)


## 计算全盘线索值（按当前变体线索型）。
func _compute_clues() -> void:
        var size := grid.size()
        var mine_set := _mine_set_dict()
        for r in size.y:
                for c in size.x:
                        var pos := Vector2i(c, r)
                        var cell := grid.get_cell(pos)
                        if cell.is_mine:
                                continue
                        cell.value = ClueEngine.compute(clue_variant, mine_set, pos, size)


## 翻开格子。第一行必须检查 state == PLAYING。
func reveal(pos: Vector2i) -> void:
        if state != GameState.PLAYING:
                return
        if grid == null or not grid.in_board(pos):
                return
        var cell := grid.get_cell(pos)
        if cell.state == Cell.State.REVEALED:
                return
        # 插旗/笔记格的翻开语义：先清除标记（P0 简化：直接翻开）
        if cell.state == Cell.State.FLAGGED or cell.state == Cell.State.QUESTION:
                cell.state = Cell.State.HIDDEN

        if cell.is_mine:
                cell.state = Cell.State.REVEALED
                cell_state_changed.emit(pos)
                state = GameState.LOST
                game_lost.emit()
                return

        _flood_reveal(pos)
        _check_win()


## 经典 0 格连锁扩散。
func _flood_reveal(start: Vector2i) -> void:
        var stack: Array[Vector2i] = [start]
        var visited: Array[Vector2i] = []
        while not stack.is_empty():
                var pos: Vector2i = stack.pop_back()
                if visited.has(pos):
                        continue
                visited.append(pos)
                var cell := grid.get_cell(pos)
                if cell.state != Cell.State.HIDDEN:
                        continue
                cell.state = Cell.State.REVEALED
                cell_state_changed.emit(pos)
                # 邻域无雷的格才连锁扩散（? 格不扩散；HV 双值/FR 射线不自动扩散）
                if cell.is_zero_clue() and not cell.is_hidden_clue():
                        for nb in grid.get_neighbors(pos):
                                var ncell := grid.get_cell(nb)
                                if ncell.state == Cell.State.HIDDEN:
                                        stack.append(nb)


## 插旗/笔记?/取消 循环标记（右键）。
func toggle_flag(pos: Vector2i) -> void:
        if state != GameState.PLAYING:
                return
        if grid == null or not grid.in_board(pos):
                return
        var cell := grid.get_cell(pos)
        if cell.state == Cell.State.REVEALED:
                return
        match cell.state:
                Cell.State.HIDDEN:
                        cell.state = Cell.State.FLAGGED
                Cell.State.FLAGGED:
                        cell.state = Cell.State.QUESTION
                Cell.State.QUESTION:
                        cell.state = Cell.State.HIDDEN
        cell_state_changed.emit(pos)


## 【双视角唯一入口】玩家视角约束集。调用方仅限求解器/提示器。
func get_player_constraint(pos: Vector2i) -> Dictionary:
        if grid == null or not grid.in_board(pos):
                return { "type": "none" }
        return grid.get_cell(pos).get_player_constraint()


## 判负唯一入口。P4 注释锁死：返回 _static ∪ _dynamic。
func is_mine(pos: Vector2i) -> bool:
        if grid == null or not grid.in_board(pos):
                return false
        return grid.get_cell(pos).is_mine


## 雷位全集。P4 语义 = _static ∪ _dynamic。
func get_mine_positions() -> Array[Vector2i]:
        return _static_mines.duplicate()


## 雷位字典（Vector2i -> true），供线索计算 / 约束检查 / 生成器使用。
func _mine_set_dict() -> Dictionary:
        var d := {}
        for m in _static_mines:
                d[m] = true
        return d


## 设置变体配置（线索型 + 可选全局约束）。
func set_variant(clue: int, constraint: int = -1, p_dominoes: Array = []) -> void:
        clue_variant = clue
        constraint_variant = constraint
        dominoes = p_dominoes


func _check_win() -> void:
        if state != GameState.PLAYING:
                return
        var size := grid.size()
        for r in size.y:
                for c in size.x:
                        var cell := grid.get_cell(Vector2i(c, r))
                        if not cell.is_mine and cell.state != Cell.State.REVEALED:
                                return
        state = GameState.WON
        game_won.emit()


## 统计信息（供 HUD / 统计使用）。
func get_stats() -> Dictionary:
        var size := grid.size()
        var revealed_count := 0
        var flagged_count := 0
        var total_non_mine := size.x * size.y - total_mines
        for r in size.y:
                for c in size.x:
                        var cell := grid.get_cell(Vector2i(c, r))
                        match cell.state:
                                Cell.State.REVEALED:
                                        revealed_count += 1
                                Cell.State.FLAGGED:
                                        flagged_count += 1
        return {
                "revealed": revealed_count,
                "flagged": flagged_count,
                "total_non_mine": total_non_mine,
                "remaining": total_non_mine - revealed_count,
        }
