# variant_constraint.gd —— 通用变体约束检查器（文档 §5.2 独立性铁律）
# 注入 BruteForceOracle 的 constraint_check 回调，支持任意线索型 + 全局约束。
# 规则自然语言定义：
#   线索格显示的值 = 该变体线索函数在其邻域/窗口上计算的结果；
#   全局约束型额外要求整盘雷分布满足对称/计数/配对等关系。
class_name VariantConstraint
extends RefCounted

# 线索型（ClueEngine.Variant）
var clue: int = ClueEngine.Variant.CLASSIC
# 全局约束（ConstraintEngine.Variant，-1 = 无）
var constraint: int = -1
var dominoes: Array = []  # DT 骨牌数据


func _init(p_clue: int = ClueEngine.Variant.CLASSIC, p_constraint: int = -1, p_dominoes: Array = []) -> void:
	clue = p_clue
	constraint = p_constraint
	dominoes = p_dominoes


## 判断候选雷分布 mine_set 是否满足全部已翻开格约束 + 全局约束。
## 签名与 BruteForceOracle.query 的 check 参数一致。
func check(mine_set: Array[Vector2i], revealed: Dictionary, grid_size: Vector2i) -> bool:
	var ms := {}
	for p in mine_set:
		ms[p] = true

	for pos in revealed:
		var c: Dictionary = revealed[pos]
		var val: Variant = ClueEngine.compute(clue, ms, pos, grid_size)
		match c.get("type", ""):
			"equality":
				if val != c["value"]:
					return false
			"equality_pair":
				if not (val is Array) or val[0] != c["a"] or val[1] != c["b"]:
					return false
			"interval":
				if not (val is int):
					return false
				if val < c["lo"] or val > c["hi"]:
					return false

	# 全局约束
	if constraint >= 0:
		if not ConstraintEngine.check(constraint, ms, grid_size, {"dominoes": dominoes}):
			return false
	return true
