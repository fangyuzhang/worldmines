# shot_driver.gd —— MVP 验收截图驱动【plan1.1 §10.12.2「等价 headless 截图方案」】
# 用途：在 xvfb 虚拟显示 + 软件渲染下驱动真实输入管线（Input.parse_input_event），
# 逐场景抓取视口帧 → user://shots/。本脚本是验收工具（非 debug_*.gd 临时脚本），
# 与交付物一同提交，交付说明注明「无 MCP，采用等价 xvfb 截图方案」。
# 技术注记：-s 模式下本脚本先于 autoload 注册编译，故 GameSession 用动态查找
# root.get_node("/root/GameSession")（编译期不解析 autoload 标识符）。
# 截图清单（§10.12.2）：①主菜单 ②关卡选择 ③对局中 ④悬停高亮 ⑤终局 ⑥恢复前后两张。
extends SceneTree

const SHOTS := "user://shots"


func _initialize() -> void:
        DirAccess.make_dir_recursive_absolute(SHOTS)
        _run()


func _gs() -> Node:
        return root.get_node("/root/GameSession")


func _run() -> void:
        print("[shot] 驱动开始")
        # ① 主菜单
        change_scene_to_file("res://ui/main_menu.tscn")
        await _frames(6)
        await _shot("01_main_menu.png")

        # ② 关卡选择（点击「开始游戏」）
        await _click_button("开始游戏")
        await _frames(4)
        await _shot("02_level_select.png")

        # ③ 对局中（点击第 1 关 → 翻开若干格 + 插 1 旗）
        await _click_button("第 1 关")
        await _frames(4)
        if not _in_board_view():
                print("[shot] 错误：当前场景不是 board_view")
                quit()
                return
        print("[dbg] center(0,0)=", _cell_center(Vector2i(0, 0)))
        print("[dbg] bv_rect=", get_current_scene().get_global_rect(),
                " mouse_filter=", get_current_scene().mouse_filter,
                " visible=", get_current_scene().is_visible_in_tree())
        await _move(Vector2(640, 400))
        await process_frame
        if root.has_method("gui_get_hovered_control"):
                print("[dbg] hovered=", root.gui_get_hovered_control())
        await _click_cell(Vector2i(0, 0))
        await _frames(2)
        var st: Dictionary = _gs().board.get_stats()
        print("[dbg] 点击后 stats=", st)
        # classic_01 事实（known_answers）：安全格含 (r1,c2)(r0,c2)(r1,c3)(r2,c2)(r2,c1)；雷含 (r0,c1)(r1,c0)
        for cell in [Vector2i(2, 1), Vector2i(2, 0), Vector2i(3, 1), Vector2i(2, 2)]:
                await _click_cell(cell)
                await _frames(2)
        await _right_click_cell(Vector2i(1, 0))  # 雷 (r0,c1) → 插旗
        await _frames(3)
        await _shot("03_playing.png")

        # ④ 悬停邻域高亮（鼠标移动到已翻开格）
        await _move_to_cell(Vector2i(2, 1))
        await _frames(3)
        await _shot("04_hover.png")

        # ⑥a 恢复前（对局进行中已自动存档；先记录盘面指纹）
        # 防抖窗口等待：距首翻存档 >5s 后再翻一格 → 触发真实自动存档（存档时点 = 当前盘面）
        await create_timer(5.6).timeout
        await _click_cell(Vector2i(2, 4))  # (r4,c2) known=1 安全格
        await _frames(2)
        var fp_before: Dictionary = _board_fingerprint()
        await _shot("06a_before_crash.png")
        # 模拟杀进程：直接回到主菜单（不清档 → TEMP 残留 → 弹恢复窗）
        _gs().state = 0  # IDLE
        _gs().board = null
        change_scene_to_file("res://ui/main_menu.tscn")
        await _frames(6)
        await _shot("06b_restore_dialog.png")
        # 确认弹窗「恢复」（弹窗为 Window 子树，rect 坐标不可靠 → 直连 confirmed 信号）
        var dlg := _find_dialog(get_current_scene())
        if dlg == null:
                print("[shot] 错误：未找到恢复弹窗")
                quit()
                return
        dlg.confirmed.emit()
        await _frames(8)
        var fp_after: Dictionary = _board_fingerprint()
        await _shot("06c_after_restore.png")
        print("[shot] 恢复一致性(盘面): ", "一致 ✓" if fp_before.hash() == fp_after.hash() else "不一致 ✗")
        print("[shot] before=", fp_before)
        print("[shot] after=", fp_after)

        # ⑤ 终局（翻开一颗雷 → 失败 + 雷位揭晓 + 引爆格高亮）
        if not _in_board_view():
                print("[shot] 错误：恢复后不在 board_view")
                quit()
                return
        await _click_cell(Vector2i(3, 0))  # 雷 (r0,c3)
        await _frames(6)
        await _shot("05_endgame.png")

        # 附加：重开后再胜一盘（验证胜利路径）——快速全翻安全格由完美玩家辅助
        print("[shot] 全部截图完成")
        quit()


# ============ 基础设施 ============

func _frames(n: int) -> void:
        for i in n:
                await process_frame


func _shot(fname: String) -> void:
        await process_frame
        await process_frame  # 等绘制稳定
        var img: Image = root.get_viewport().get_texture().get_image()
        var err := img.save_png(SHOTS + "/" + fname)
        print("[shot] ", fname, " → ", "OK" if err == OK else "失败" + str(err))


func _all_buttons() -> Array:
        var out: Array = []
        _collect_buttons(get_current_scene(), out)
        return out


func _collect_buttons(n: Node, out: Array) -> void:
        if n is Button:
                out.append(n)
        for c in n.get_children():
                _collect_buttons(c, out)


func _click_button(text: String) -> void:
        for b in _all_buttons():
                if text in b.text:
                        await _click(b.get_global_rect().get_center())
                        return
        # 弹窗按钮可能在 Window 子树（AcceptDialog 内部按钮）
        for w in root.get_children():
                if w is ConfirmationDialog and w.visible:
                        var ok_b: Button = w.get_ok_button()
                        if ok_b != null and text in ok_b.text:
                                await _click(ok_b.get_global_rect().get_center())
                                return
        print("[shot] 未找到按钮: ", text)


func _click(pos: Vector2) -> void:
        var ev := InputEventMouseButton.new()
        ev.position = pos
        ev.global_position = pos
        ev.button_index = MOUSE_BUTTON_LEFT
        ev.pressed = true
        Input.parse_input_event(ev)
        await process_frame
        var ev2 := ev.duplicate()
        ev2.pressed = false
        Input.parse_input_event(ev2)
        await process_frame


func _right_click(pos: Vector2) -> void:
        var ev := InputEventMouseButton.new()
        ev.position = pos
        ev.global_position = pos
        ev.button_index = MOUSE_BUTTON_RIGHT
        ev.pressed = true
        Input.parse_input_event(ev)
        await process_frame
        var ev2 := ev.duplicate()
        ev2.pressed = false
        Input.parse_input_event(ev2)
        await process_frame


func _move(pos: Vector2) -> void:
        var ev := InputEventMouseMotion.new()
        ev.position = pos
        ev.global_position = pos
        Input.parse_input_event(ev)
        await process_frame


func _in_board_view() -> bool:
        var cur: Node = get_current_scene()
        return cur != null and cur.get_script() != null \
                and cur.get_script().resource_path == "res://ui/board_view.gd"


## 格中心（board_view 公开 board_origin / cell_px）。
func _cell_center(cell: Vector2i) -> Vector2:
        var bv: Control = get_current_scene()
        return bv.board_origin + (Vector2(cell.x, cell.y) + Vector2(0.5, 0.5)) * bv.cell_px


func _click_cell(cell: Vector2i) -> void:
        await _click(_cell_center(cell))


func _right_click_cell(cell: Vector2i) -> void:
        await _right_click(_cell_center(cell))


func _move_to_cell(cell: Vector2i) -> void:
        await _move(_cell_center(cell))


## 盘面指纹（恢复前后一致性验证：翻开格集合 + 旗格集合；elapsed 一致性由 GUT t11b 精确断言）。
func _board_fingerprint() -> Dictionary:
        var b: Board = _gs().get("board")
        if b == null or b.grid == null:
                return {}
        var size := b.grid.size()
        var revealed: Array = []
        var flagged: Array = []
        for r in size.y:
                for c in size.x:
                        match b.grid.get_cell(Vector2i(c, r)).state:
                                Cell.State.REVEALED:
                                        revealed.append([c, r])
                                Cell.State.FLAGGED:
                                        flagged.append([c, r])
        return {"revealed": revealed, "flagged": flagged}


func _find_dialog(n: Node) -> ConfirmationDialog:
        if n is ConfirmationDialog:
                return n
        for c in n.get_children():
                var d: ConfirmationDialog = _find_dialog(c)
                if d != null:
                        return d
        return null
